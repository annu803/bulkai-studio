package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BulkAiRepository
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repository = BulkAiRepository.getInstance()

        setContent {
            BulkAITheme {
                BulkAiApp(repository = repository)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BulkAiApp(repository: BulkAiRepository) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    var currentDestination by remember { mutableStateOf(AppDestination.DASHBOARD) }

    val credits by repository.credits.collectAsState()
    val isMockMode by repository.isMockMode.collectAsState()
    val selectedTier by repository.selectedTier.collectAsState()

    // Handle back button when drawer is open or returning to dashboard
    BackHandler(enabled = drawerState.isOpen || currentDestination != AppDestination.DASHBOARD) {
        if (drawerState.isOpen) {
            coroutineScope.launch { drawerState.close() }
        } else {
            currentDestination = AppDestination.DASHBOARD
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = SaaSSurface,
                drawerContentColor = TextPrimaryDark,
                modifier = Modifier.width(300.dp)
            ) {
                DrawerContent(
                    currentDestination = currentDestination,
                    onDestinationSelected = { dest ->
                        currentDestination = dest
                        coroutineScope.launch { drawerState.close() }
                    },
                    credits = credits,
                    isMockMode = isMockMode,
                    onToggleMockMode = { repository.setMockMode(it) }
                )
            }
        }
    ) {
        Scaffold(
            containerColor = ObsidianBackground,
            topBar = {
                Surface(
                    color = SaaSSurface,
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.verticalGradient(
                            listOf(SaaSSurfaceBorder, Color.Transparent)
                        )
                    )
                ) {
                    TopAppBar(
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0xFF2563EB), Color(0xFF7C3AED))
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = "Logo",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "BulkAI Studio",
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = currentDestination.title,
                                        color = Color(0xFF93C5FD),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = {
                                    coroutineScope.launch {
                                        if (drawerState.isClosed) drawerState.open() else drawerState.close()
                                    }
                                },
                                modifier = Modifier.testTag("btn_navigation_drawer")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Menu,
                                    contentDescription = "Open Drawer",
                                    tint = TextPrimaryDark
                                )
                            }
                        },
                        actions = {
                            // Mock Mode Badge
                            Surface(
                                color = if (isMockMode) Color(0xFF064E3B) else Color(0xFF1E3A8A),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .padding(end = 6.dp)
                                    .clickable { repository.setMockMode(!isMockMode) }
                                    .testTag("badge_mock_mode")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(if (isMockMode) Color(0xFF34D399) else Color(0xFF60A5FA))
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isMockMode) "MOCK" else "LIVE",
                                        color = if (isMockMode) Color(0xFF6EE7B7) else Color(0xFF93C5FD),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Credits Pill
                            Surface(
                                color = SaaSSurfaceCard,
                                shape = RoundedCornerShape(12.dp),
                                border = CardDefaults.outlinedCardBorder().copy(
                                    brush = Brush.horizontalGradient(
                                        listOf(Color(0xFFF59E0B).copy(alpha = 0.4f), Color(0xFF3B82F6).copy(alpha = 0.4f))
                                    )
                                ),
                                modifier = Modifier
                                    .padding(end = 12.dp)
                                    .clickable { currentDestination = AppDestination.CREDITS }
                                    .testTag("top_bar_credits_pill")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = "Credits",
                                        tint = Color(0xFFFBBF24),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "$credits",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.Transparent,
                            titleContentColor = Color.White
                        )
                    )
                }
            },
            bottomBar = {
                // Bottom navigation bar for primary actions
                NavigationBar(
                    containerColor = SaaSSurface,
                    contentColor = TextPrimaryDark,
                    tonalElevation = 8.dp
                ) {
                    val bottomDestinations = listOf(
                        AppDestination.DASHBOARD,
                        AppDestination.BULK_VIDEO,
                        AppDestination.BULK_IMAGE,
                        AppDestination.AI_SCRIPT,
                        AppDestination.VOICE_OVER
                    )

                    bottomDestinations.forEach { destination ->
                        val isSelected = currentDestination == destination
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentDestination = destination },
                            icon = {
                                Icon(
                                    imageVector = destination.icon,
                                    contentDescription = destination.title,
                                    modifier = Modifier.size(20.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = destination.title,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color(0xFF60A5FA),
                                unselectedIconColor = TextSecondaryDark,
                                selectedTextColor = Color.White,
                                unselectedTextColor = TextMutedDark,
                                indicatorColor = Color(0xFF1E293B)
                            ),
                            modifier = Modifier.testTag("bottom_nav_${destination.name.lowercase()}")
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (currentDestination) {
                    AppDestination.DASHBOARD -> DashboardScreen(
                        repository = repository,
                        onNavigate = { currentDestination = it }
                    )
                    AppDestination.BULK_VIDEO -> BulkVideoScreen(
                        repository = repository
                    )
                    AppDestination.BULK_IMAGE -> BulkImageScreen(
                        repository = repository
                    )
                    AppDestination.AI_SCRIPT -> ScriptToSceneScreen(
                        repository = repository,
                        onNavigate = { currentDestination = it }
                    )
                    AppDestination.VOICE_OVER -> VoiceOverScreen(
                        repository = repository
                    )
                    AppDestination.PROJECTS -> ProjectsScreen(
                        repository = repository,
                        onNavigate = { currentDestination = it }
                    )
                    AppDestination.CREDITS -> CreditsScreen(
                        repository = repository
                    )
                    AppDestination.PRICING -> PricingScreen(
                        repository = repository
                    )
                    AppDestination.ADMIN_PANEL -> AdminPanelScreen(
                        repository = repository
                    )
                    AppDestination.SETTINGS -> SettingsScreen(
                        repository = repository
                    )
                }
            }
        }
    }
}
