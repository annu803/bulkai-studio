package com.example.data

import com.example.data.providers.*
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * AI Router Architecture
 * ├── Image Provider (ImageProvider)
 * ├── Video Provider (VideoProvider)
 * └── Voice Provider (VoiceProvider)
 *
 * Responsibilities:
 * - Selects and manages providers for each modality (Image, Video, Voice, Script).
 * - Tracks Provider Status: MOCK / CONFIGURED / UNAVAILABLE.
 * - Resolves models per tier (Economy, Standard, Premium).
 * - Dispatches generation requests with Request IDs, job IDs, retry policies,
 *   timeout handling, and compute cost tracking.
 * - Currently operates in 100% MOCK MODE using Mock providers with zero paid API calls.
 * - Prepared for future zero-rebuild commercial AI API connection (Google Veo, Kling, Flux, ElevenLabs).
 */
class AiRouter(
    private var mockModeEnabled: Boolean = true
) {
    // Current Active Providers
    private var mockImageProvider: ImageProvider = MockImageProvider()
    private var replicateEconomyProvider: ImageProvider = ReplicateImageProvider(ImageGenerationMode.REPLICATE_ECONOMY)
    private var replicatePremiumProvider: ImageProvider = ReplicateImageProvider(ImageGenerationMode.REPLICATE_PREMIUM)

    private var imageProvider: ImageProvider = mockImageProvider
    private var currentImageMode: ImageGenerationMode = ImageGenerationMode.MOCK

    private var videoProvider: VideoProvider = MockVideoProvider()
    private var voiceProvider: VoiceProvider = MockVoiceProvider()

    // Metrics for Admin telemetry
    private var replicateRequestsCount: Int = 0
    private var replicateCompletedCount: Int = 0
    private var replicateFailedCount: Int = 0
    private var replicateTotalCostUsd: Double = 0.0

    private val _routerState = MutableStateFlow(buildProviderStatusList())
    val routerState: StateFlow<List<ProviderInfo>> = _routerState.asStateFlow()

    fun isMockMode(): Boolean = mockModeEnabled

    fun setMockMode(enabled: Boolean) {
        mockModeEnabled = enabled
        if (enabled) {
            currentImageMode = ImageGenerationMode.MOCK
            imageProvider = mockImageProvider
        } else {
            if (currentImageMode == ImageGenerationMode.MOCK) {
                currentImageMode = ImageGenerationMode.REPLICATE_ECONOMY
                imageProvider = replicateEconomyProvider
            }
        }
        _routerState.value = buildProviderStatusList()
    }

    fun getCurrentImageMode(): ImageGenerationMode = currentImageMode

    fun setImageGenerationMode(mode: ImageGenerationMode) {
        currentImageMode = mode
        imageProvider = when (mode) {
            ImageGenerationMode.MOCK -> mockImageProvider
            ImageGenerationMode.REPLICATE_ECONOMY -> replicateEconomyProvider
            ImageGenerationMode.REPLICATE_PREMIUM -> replicatePremiumProvider
        }
        mockModeEnabled = (mode == ImageGenerationMode.MOCK)
        _routerState.value = buildProviderStatusList()
    }

    // Provider Accessors
    fun getImageProvider(): ImageProvider = imageProvider
    fun getVideoProvider(): VideoProvider = videoProvider
    fun getVoiceProvider(): VoiceProvider = voiceProvider
    fun getReplicateEconomyProvider(): ImageProvider = replicateEconomyProvider
    fun getReplicatePremiumProvider(): ImageProvider = replicatePremiumProvider

    fun getReplicateStats(): Map<String, Any> {
        return mapOf(
            "requests" to replicateRequestsCount,
            "completed" to replicateCompletedCount,
            "failed" to replicateFailedCount,
            "totalCostUsd" to replicateTotalCostUsd
        )
    }

    fun recordReplicateJobResult(success: Boolean, costUsd: Double) {
        replicateRequestsCount++
        if (success) {
            replicateCompletedCount++
            replicateTotalCostUsd += costUsd
        } else {
            replicateFailedCount++
        }
        _routerState.value = buildProviderStatusList()
    }

    /**
     * Plug-in hooks to attach future commercial AI providers at runtime
     * without changing UI or calling components.
     */
    fun registerImageProvider(provider: ImageProvider) {
        this.imageProvider = provider
        _routerState.value = buildProviderStatusList()
    }

    fun registerVideoProvider(provider: VideoProvider) {
        this.videoProvider = provider
        _routerState.value = buildProviderStatusList()
    }

    fun registerVoiceProvider(provider: VoiceProvider) {
        this.voiceProvider = provider
        _routerState.value = buildProviderStatusList()
    }

    // Model name resolvers
    fun resolveVideoModel(tier: ModelTier): String {
        return when (tier) {
            ModelTier.ECONOMY -> "Wan 2.1 Video (Fast)"
            ModelTier.STANDARD -> "Kling AI v1.5 High"
            ModelTier.PREMIUM -> "Google Veo 2 Ultra"
        }
    }

    fun resolveImageModel(tier: ModelTier): String {
        return when (tier) {
            ModelTier.ECONOMY -> "FastFlux Nano v2"
            ModelTier.STANDARD -> "SDXL Turbo Lightning"
            ModelTier.PREMIUM -> "Midjourney v6 Photoreal"
        }
    }

    fun resolveVoiceModel(tier: ModelTier): String {
        return when (tier) {
            ModelTier.ECONOMY -> "ElevenLabs Standard TTS"
            ModelTier.STANDARD -> "ElevenLabs Multilingual v2"
            ModelTier.PREMIUM -> "DeepMind Natural WaveNet 2"
        }
    }

    fun resolveScriptModel(tier: ModelTier): String {
        return when (tier) {
            ModelTier.ECONOMY -> "Gemini 1.5 Flash"
            ModelTier.STANDARD -> "Gemini 2.0 Flash"
            ModelTier.PREMIUM -> "Gemini 1.5 Pro Ultra"
        }
    }

    /**
     * Builds summary of provider statuses for Admin / Developer displays
     */
    fun buildProviderStatusList(): List<ProviderInfo> {
        val replicateEconStatus = replicateEconomyProvider.getStatus()
        val replicatePremStatus = replicatePremiumProvider.getStatus()

        return listOf(
            ProviderInfo(
                category = "Image Provider (Active)",
                activeProviderName = if (mockModeEnabled) "Mock" else imageProvider.providerName,
                status = if (mockModeEnabled) ProviderStatus.MOCK else imageProvider.getStatus(),
                modelName = if (mockModeEnabled) "FastFlux / SDXL (Simulated)" else currentImageMode.modelIdentifier,
                isMock = mockModeEnabled,
                note = if (mockModeEnabled) "Simulated diffusion synthesis. Zero API billing." else "Connected to live API."
            ),
            ProviderInfo(
                category = "Replicate Economy",
                activeProviderName = "Replicate",
                status = replicateEconStatus,
                modelName = AiProviderPricingConfig.REPLICATE_ECONOMY_MODEL,
                isMock = false,
                note = "Primary Economy Image Model ($0.01 / image). Requires REPLICATE_API_TOKEN."
            ),
            ProviderInfo(
                category = "Replicate Premium",
                activeProviderName = "Replicate",
                status = replicatePremStatus,
                modelName = AiProviderPricingConfig.REPLICATE_PREMIUM_MODEL,
                isMock = false,
                note = "Premium Image Model ($0.04 / image). Requires REPLICATE_API_TOKEN."
            ),
            ProviderInfo(
                category = "Video Generation",
                activeProviderName = if (mockModeEnabled) "Mock" else videoProvider.providerName,
                status = if (mockModeEnabled) ProviderStatus.MOCK else videoProvider.getStatus(),
                modelName = "Google Veo 2 / Kling v1.5",
                isMock = mockModeEnabled,
                note = "Zero API billing. Simulated temporal frame generation."
            ),
            ProviderInfo(
                category = "Text-to-Speech (Voice)",
                activeProviderName = if (mockModeEnabled) "Mock" else voiceProvider.providerName,
                status = if (mockModeEnabled) ProviderStatus.MOCK else voiceProvider.getStatus(),
                modelName = "ElevenLabs Multilingual v2",
                isMock = mockModeEnabled,
                note = "Zero API billing. Simulated phoneme alignment & speech synthesis."
            ),
            ProviderInfo(
                category = "Script & Scene AI",
                activeProviderName = if (mockModeEnabled) "Mock" else "Gemini Flash",
                status = if (mockModeEnabled) ProviderStatus.MOCK else ProviderStatus.CONFIGURED,
                modelName = "Gemini 2.0 Flash / Pro",
                isMock = mockModeEnabled,
                note = "Zero API billing. Procedural multi-scene documentary generation."
            )
        )
    }

    /**
     * Executes an image generation request through the configured ImageProvider
     * with timeout handling, request ID tagging, and error management.
     */
    suspend fun routeImageGeneration(
        jobId: String,
        prompt: String,
        settings: ImageGenerationSettings,
        customRequestId: String? = null,
        targetMode: ImageGenerationMode? = null
    ): ProviderResponse<ImageOutput> {
        val activeMode = targetMode ?: currentImageMode
        val provider = when (activeMode) {
            ImageGenerationMode.MOCK -> mockImageProvider
            ImageGenerationMode.REPLICATE_ECONOMY -> replicateEconomyProvider
            ImageGenerationMode.REPLICATE_PREMIUM -> replicatePremiumProvider
        }

        val request = ProviderRequest(
            requestId = customRequestId ?: "req-img-${System.currentTimeMillis()}-${(1000..9999).random()}",
            jobId = jobId,
            prompt = prompt,
            timeoutMillis = 120000L
        )

        val response = try {
            provider.generate(request, settings)
        } catch (e: Exception) {
            val errorMsg = provider.handleError(e, request.requestId)
            ProviderResponse(
                success = false,
                requestId = request.requestId,
                jobId = jobId,
                error = errorMsg,
                providerName = provider.providerName
            )
        }

        if (activeMode != ImageGenerationMode.MOCK) {
            recordReplicateJobResult(response.success, response.estimatedCostUsd)
        }

        return response
    }

    /**
     * Executes a video generation request through the configured VideoProvider.
     */
    suspend fun routeVideoGeneration(
        jobId: String,
        prompt: String,
        settings: VideoGenerationSettings
    ): ProviderResponse<VideoOutput> {
        val request = ProviderRequest(
            requestId = "req-vid-${System.currentTimeMillis()}-${(1000..9999).random()}",
            jobId = jobId,
            prompt = prompt,
            timeoutMillis = 45000L
        )

        return try {
            videoProvider.generate(request, settings)
        } catch (e: Exception) {
            val errorMsg = videoProvider.handleError(e, request.requestId)
            ProviderResponse(
                success = false,
                requestId = request.requestId,
                jobId = jobId,
                error = errorMsg,
                providerName = videoProvider.providerName
            )
        }
    }

    /**
     * Executes a voice synthesis request through the configured VoiceProvider.
     */
    suspend fun routeVoiceGeneration(
        jobId: String,
        text: String,
        config: VoiceConfig,
        tier: ModelTier = ModelTier.STANDARD
    ): ProviderResponse<VoiceOutput> {
        val request = ProviderRequest(
            requestId = "req-tts-${System.currentTimeMillis()}-${(1000..9999).random()}",
            jobId = jobId,
            prompt = text,
            timeoutMillis = 20000L
        )

        return try {
            voiceProvider.generate(request, config, tier)
        } catch (e: Exception) {
            val errorMsg = voiceProvider.handleError(e, request.requestId)
            ProviderResponse(
                success = false,
                requestId = request.requestId,
                jobId = jobId,
                error = errorMsg,
                providerName = voiceProvider.providerName
            )
        }
    }
}
