package com.example.data

import com.example.data.providers.*
import com.example.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

class BulkAiRepository private constructor() {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

    val aiRouter = AiRouter(mockModeEnabled = true)
    val imageService: ImageGenerationService = MockImageGenerationService()

    private val _isMockMode = MutableStateFlow(true)
    val isMockMode: StateFlow<Boolean> = _isMockMode.asStateFlow()

    private val _selectedTier = MutableStateFlow(ModelTier.STANDARD)
    val selectedTier: StateFlow<ModelTier> = _selectedTier.asStateFlow()

    private val _credits = MutableStateFlow(1250)
    val credits: StateFlow<Int> = _credits.asStateFlow()

    private val _jobs = MutableStateFlow<List<GenerationJob>>(emptyList())
    val jobs: StateFlow<List<GenerationJob>> = _jobs.asStateFlow()

    private val _projects = MutableStateFlow<List<SaaSProject>>(emptyList())
    val projects: StateFlow<List<SaaSProject>> = _projects.asStateFlow()

    private val _transactions = MutableStateFlow<List<CreditTransaction>>(emptyList())
    val transactions: StateFlow<List<CreditTransaction>> = _transactions.asStateFlow()

    private val _currentScript = MutableStateFlow<DocumentaryScript?>(null)
    val currentScript: StateFlow<DocumentaryScript?> = _currentScript.asStateFlow()

    private val _isGeneratingScript = MutableStateFlow(false)
    val isGeneratingScript: StateFlow<Boolean> = _isGeneratingScript.asStateFlow()

    private val _adminUsers = MutableStateFlow<List<SaaSUser>>(emptyList())
    val adminUsers: StateFlow<List<SaaSUser>> = _adminUsers.asStateFlow()

    private var jobSequence = 1

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        // Initial sample projects
        _projects.value = listOf(
            SaaSProject(
                id = "proj-1",
                name = "Ancient Indian Temples Documentary",
                type = "AI Documentary",
                sceneCount = 12,
                videoCount = 12,
                imageCount = 24,
                createdAt = "2026-09-02",
                status = "Active"
            ),
            SaaSProject(
                id = "proj-2",
                name = "Himalayan Glaciers 4K Series",
                type = "Video Campaign",
                sceneCount = 8,
                videoCount = 8,
                imageCount = 16,
                createdAt = "2026-09-04",
                status = "Completed"
            ),
            SaaSProject(
                id = "proj-3",
                name = "Top 10 Cities of India Voiceover",
                type = "Voice Series",
                sceneCount = 10,
                videoCount = 10,
                imageCount = 0,
                createdAt = "2026-09-06",
                status = "Active"
            )
        )

        // Initial sample credit transactions
        _transactions.value = listOf(
            CreditTransaction("tx-1", "Plan Allocation", 1500, "Monthly Pro Plan Subscription", "2026-09-01 10:00", "Completed"),
            CreditTransaction("tx-2", "Bulk Video", -160, "Generated 8x 4K Videos (Kling v1.5)", "2026-09-04 14:32", "Completed"),
            CreditTransaction("tx-3", "Bulk Image", -60, "Generated 12x Concept Visuals (SDXL)", "2026-09-05 18:15", "Completed"),
            CreditTransaction("tx-4", "Voice Over", -30, "Generated 5 Hindi Documentary Audio Clips", "2026-09-06 09:20", "Completed")
        )

        // Sample admin users
        _adminUsers.value = listOf(
            SaaSUser("u-1", "Amit Shukla", "amitshukla@bulkai.studio", "STUDIO ₹999", 1250, false, "2026-08-01"),
            SaaSUser("u-2", "Vikram Malhotra", "vikram@creativestudios.in", "PRO ₹599", 840, false, "2026-08-10"),
            SaaSUser("u-3", "Priya Sharma", "priya.ai@contenthub.com", "CREATOR ₹299", 310, false, "2026-08-18"),
            SaaSUser("u-4", "Devendra Patel", "devendra@filmcraft.io", "STARTER ₹99", 45, false, "2026-08-25"),
            SaaSUser("u-5", "Rohan Verma", "rohan.v@agency.net", "FREE ₹0", 0, true, "2026-08-30")
        )

        // Preload sample completed jobs so dashboard looks rich immediately
        val initialJobs = listOf(
            GenerationJob(
                id = "job-init-1",
                jobNumber = "JOB-001",
                prompt = "A realistic aerial shot of an ancient Indian temple at sunrise with morning mist rising over golden spires.",
                type = JobType.VIDEO,
                status = JobStatus.COMPLETED,
                progress = 100,
                model = "Google Veo 2",
                duration = "8 seconds",
                aspectRatio = "16:9",
                quality = "High",
                style = "Cinematic",
                previewAccentColor = 0xFFD97706
            ),
            GenerationJob(
                id = "job-init-2",
                jobNumber = "JOB-002",
                prompt = "Cinematic historical street scene in medieval India with bustling artisan bazaar and dramatic sunlight.",
                type = JobType.VIDEO,
                status = JobStatus.COMPLETED,
                progress = 100,
                model = "Kling v1.5",
                duration = "8 seconds",
                aspectRatio = "16:9",
                quality = "High",
                style = "Historical",
                previewAccentColor = 0xFF7C3AED
            ),
            GenerationJob(
                id = "job-init-3",
                jobNumber = "JOB-003",
                prompt = "Ultra realistic documentary shot of ancient Rajasthan hill fort walls overlooking desert sunset.",
                type = JobType.IMAGE,
                status = JobStatus.COMPLETED,
                progress = 100,
                model = "Midjourney v6",
                duration = "Instant",
                aspectRatio = "1:1",
                quality = "High",
                style = "Documentary",
                previewAccentColor = 0xFF059669
            )
        )
        _jobs.value = initialJobs
        jobSequence = 4
    }

    fun setMockMode(enabled: Boolean) {
        _isMockMode.value = enabled
        aiRouter.setMockMode(enabled)
    }

    fun setModelTier(tier: ModelTier) {
        _selectedTier.value = tier
    }

    fun addBulkVideoJobs(
        prompts: List<String>,
        duration: String,
        aspectRatio: String,
        quality: String,
        style: String,
        tier: ModelTier
    ) {
        val model = aiRouter.resolveVideoModel(tier)
        val creditCostPerJob = when (duration) {
            "5 seconds" -> 10 * tier.creditMultiplier
            "8 seconds" -> 15 * tier.creditMultiplier
            else -> 20 * tier.creditMultiplier
        }
        val totalCost = creditCostPerJob * prompts.size

        if (_credits.value >= totalCost) {
            _credits.value -= totalCost
            val timeStr = dateFormat.format(Date())
            _transactions.value = listOf(
                CreditTransaction(
                    id = "tx-${System.currentTimeMillis()}",
                    type = "Bulk Video",
                    amount = -totalCost,
                    description = "Queued ${prompts.size} video generation jobs ($model)",
                    timestamp = timeStr
                )
            ) + _transactions.value
        }

        val newJobs = prompts.map { rawPrompt ->
            val cleanPrompt = cleanPromptText(rawPrompt)
            val numStr = String.format(Locale.US, "JOB-%03d", jobSequence++)
            val colorAccents = listOf(0xFF2563EB, 0xFF7C3AED, 0xFF059669, 0xFFD97706, 0xFFDB2777)
            val accent = colorAccents[jobSequence % colorAccents.size]
            val reqId = "req-vid-${System.currentTimeMillis()}-${(1000..9999).random()}"
            val activeProvider = aiRouter.getVideoProvider().providerName

            GenerationJob(
                id = UUID.randomUUID().toString(),
                jobNumber = numStr,
                prompt = cleanPrompt,
                type = JobType.VIDEO,
                status = JobStatus.WAITING,
                progress = 0,
                model = model,
                duration = duration,
                aspectRatio = aspectRatio,
                quality = quality,
                style = style,
                previewAccentColor = accent,
                requestId = reqId,
                providerName = activeProvider,
                estimatedCostUsd = when (tier) {
                    ModelTier.ECONOMY -> 0.04
                    ModelTier.STANDARD -> 0.08
                    ModelTier.PREMIUM -> 0.20
                }
            )
        }

        _jobs.value = newJobs + _jobs.value
        startQueueRunner()
    }

    fun addBulkImageJobs(
        prompts: List<String>,
        aspectRatio: String,
        quality: String,
        style: String,
        tier: ModelTier,
        projectId: String? = null,
        imagesPerPrompt: Int = 1,
        mode: ImageGenerationMode = aiRouter.getCurrentImageMode()
    ) {
        val activeProvider = aiRouter.getImageProvider()
        val isRealReplicate = mode != ImageGenerationMode.MOCK

        val modelName = if (isRealReplicate) mode.modelIdentifier else aiRouter.resolveImageModel(tier)
        val providerDisplay = if (isRealReplicate) "Replicate" else "Mock"

        val costPerImageCredits = AiProviderPricingConfig.getCreditCost(mode, quality)
        val totalJobsCount = prompts.size * imagesPerPrompt
        val totalCreditsRequired = costPerImageCredits * totalJobsCount

        // Credit check and reservation
        if (_credits.value < totalCreditsRequired) {
            return
        }

        // Reserve credits immediately
        _credits.value -= totalCreditsRequired
        val timeStr = dateFormat.format(Date())
        val txDesc = if (isRealReplicate) {
            "Reserved $totalCreditsRequired credits for $totalJobsCount image generation jobs via Replicate ($modelName)"
        } else {
            "Queued $totalJobsCount image generation tasks ($modelName)"
        }

        _transactions.value = listOf(
            CreditTransaction(
                id = "tx-${System.currentTimeMillis()}",
                type = if (isRealReplicate) "Real Image (Replicate)" else "Bulk Image",
                amount = -totalCreditsRequired,
                description = txDesc,
                timestamp = timeStr
            )
        ) + _transactions.value

        val newJobs = mutableListOf<GenerationJob>()
        prompts.forEachIndexed { _, rawPrompt ->
            val cleanPrompt = cleanPromptText(rawPrompt)
            for (variant in 1..imagesPerPrompt) {
                val numStr = String.format(Locale.US, "IMG-%03d", jobSequence++)
                val colorAccents = listOf(0xFF0D9488, 0xFFEA580C, 0xFF4F46E5, 0xFFE11D48, 0xFF16A34A, 0xFF7C3AED)
                val accent = colorAccents[jobSequence % colorAccents.size]

                val variantSuffix = if (imagesPerPrompt > 1) " (Variant $variant/$imagesPerPrompt)" else ""
                val promptWithVariant = cleanPrompt + variantSuffix

                val reqId = "req-img-${System.currentTimeMillis()}-${(1000..9999).random()}"
                val estimatedCostUsd = AiProviderPricingConfig.getEstimatedProviderCostUsd(mode)

                newJobs.add(
                    GenerationJob(
                        id = UUID.randomUUID().toString(),
                        jobNumber = numStr,
                        prompt = promptWithVariant,
                        type = JobType.IMAGE,
                        status = JobStatus.WAITING,
                        progress = 0,
                        model = modelName,
                        duration = if (isRealReplicate) "Async API" else "Instant",
                        aspectRatio = aspectRatio,
                        quality = quality,
                        style = style,
                        previewAccentColor = accent,
                        projectId = projectId,
                        requestId = reqId,
                        providerName = providerDisplay,
                        mode = mode.name,
                        estimatedCostUsd = estimatedCostUsd,
                        creditsCharged = costPerImageCredits
                    )
                )
            }
        }

        _jobs.value = newJobs + _jobs.value
        startQueueRunner()
    }

    fun addVoiceJob(text: String, config: VoiceConfig) {
        val tier = _selectedTier.value
        val model = aiRouter.resolveVoiceModel(tier)
        val cost = 8 * tier.creditMultiplier

        if (_credits.value >= cost) {
            _credits.value -= cost
            val timeStr = dateFormat.format(Date())
            _transactions.value = listOf(
                CreditTransaction(
                    id = "tx-${System.currentTimeMillis()}",
                    type = "Voice Over",
                    amount = -cost,
                    description = "Queued voiceover in ${config.language} (${config.voiceName})",
                    timestamp = timeStr
                )
            ) + _transactions.value
        }

        val numStr = String.format(Locale.US, "JOB-%03d", jobSequence++)
        val reqId = "req-tts-${System.currentTimeMillis()}-${(1000..9999).random()}"
        val activeProvider = aiRouter.getVoiceProvider().providerName

        val job = GenerationJob(
            id = UUID.randomUUID().toString(),
            jobNumber = numStr,
            prompt = text.take(120),
            type = JobType.VOICE,
            status = JobStatus.WAITING,
            progress = 0,
            model = model,
            duration = "Audio Clip",
            aspectRatio = "1:1",
            quality = "Lossless 48kHz",
            style = config.style,
            previewAccentColor = 0xFF8B5CF6,
            voiceScript = text,
            voiceSpeaker = "${config.voiceName} (${config.language})",
            requestId = reqId,
            providerName = activeProvider,
            estimatedCostUsd = text.length * 0.00015
        )

        _jobs.value = listOf(job) + _jobs.value
        startQueueRunner()
    }

    private var isQueueRunning = false

    private fun startQueueRunner() {
        if (isQueueRunning) return
        isQueueRunning = true

        scope.launch {
            while (true) {
                val currentJobs = _jobs.value
                val waitingJobs = currentJobs.filter { it.status == JobStatus.WAITING }
                val processingJobs = currentJobs.filter { it.status == JobStatus.PROCESSING }

                if (waitingJobs.isEmpty() && processingJobs.isEmpty()) {
                    isQueueRunning = false
                    break
                }

                // Allow up to 3 jobs to process concurrently
                val maxConcurrent = 3
                val slotsAvailable = maxConcurrent - processingJobs.size

                if (slotsAvailable > 0 && waitingJobs.isNotEmpty()) {
                    val toStart = waitingJobs.take(slotsAvailable)
                    _jobs.value = _jobs.value.map { job ->
                        if (toStart.any { it.id == job.id }) {
                            job.copy(status = JobStatus.PROCESSING, progress = Random.nextInt(10, 25))
                        } else job
                    }
                }

                // Advance progress for processing jobs
                delay(750)
                _jobs.value = _jobs.value.map { job ->
                    if (job.status == JobStatus.PROCESSING) {
                        val isRealReplicateImage = job.type == JobType.IMAGE && (
                            job.mode == ImageGenerationMode.REPLICATE_ECONOMY.name ||
                            job.mode == ImageGenerationMode.REPLICATE_PREMIUM.name ||
                            job.providerName == "Replicate"
                        )

                        if (isRealReplicateImage) {
                            val jobModeEnum = when (job.mode) {
                                ImageGenerationMode.REPLICATE_PREMIUM.name -> ImageGenerationMode.REPLICATE_PREMIUM
                                ImageGenerationMode.REPLICATE_ECONOMY.name -> ImageGenerationMode.REPLICATE_ECONOMY
                                else -> ImageGenerationMode.REPLICATE_ECONOMY
                            }
                            // Run Replicate real prediction asynchronously without blocking the loop
                            val resp = runBlocking {
                                aiRouter.routeImageGeneration(
                                    jobId = job.id,
                                    prompt = job.prompt,
                                    settings = ImageGenerationSettings(
                                        aspectRatio = job.aspectRatio,
                                        quality = job.quality,
                                        style = job.style,
                                        projectId = job.projectId,
                                        tier = _selectedTier.value
                                    ),
                                    customRequestId = job.requestId,
                                    targetMode = jobModeEnum
                                )
                            }

                            if (resp.success && resp.data != null) {
                                if (job.projectId != null) {
                                    incrementProjectImageCount(job.projectId)
                                }
                                job.copy(
                                    status = JobStatus.COMPLETED,
                                    progress = 100,
                                    completedAt = System.currentTimeMillis(),
                                    imageUrl = resp.data.imageUrl,
                                    providerName = resp.providerName,
                                    estimatedCostUsd = resp.estimatedCostUsd,
                                    requestId = resp.requestId
                                )
                            } else {
                                // Generation failed before successful completion -> refund reserved credits
                                if (job.creditsCharged > 0) {
                                    _credits.value += job.creditsCharged
                                    _transactions.value = listOf(
                                        CreditTransaction(
                                            id = "tx-refund-${System.currentTimeMillis()}",
                                            type = "Refund",
                                            amount = job.creditsCharged,
                                            description = "Refunded ${job.creditsCharged} credits for failed job ${job.jobNumber} (${resp.error ?: "Provider error"})",
                                            timestamp = dateFormat.format(Date())
                                        )
                                    ) + _transactions.value
                                }
                                job.copy(
                                    status = JobStatus.FAILED,
                                    progress = 0,
                                    error = resp.error ?: "Replicate API prediction failed. Tap Retry to try again.",
                                    requestId = resp.requestId
                                )
                            }
                        } else {
                            // Standard Mock Progression
                            val nextProgress = job.progress + Random.nextInt(20, 35)
                            if (nextProgress >= 100) {
                                val isSimulatedFailure = job.prompt.contains("error", ignoreCase = true) ||
                                        job.prompt.contains("fail", ignoreCase = true)

                                if (isSimulatedFailure) {
                                    // Refund if mock credits were charged
                                    if (job.creditsCharged > 0) {
                                        _credits.value += job.creditsCharged
                                    }
                                    job.copy(
                                        status = JobStatus.FAILED,
                                        progress = 0,
                                        error = "GPU cluster timeout / out of memory during synthesis. Tap retry to re-queue."
                                    )
                                } else {
                                    var resolvedImageUrl = job.imageUrl
                                    var resolvedProviderName = job.providerName
                                    var resolvedEstimatedCost = job.estimatedCostUsd

                                    when (job.type) {
                                        JobType.IMAGE -> {
                                            val resp = runBlocking {
                                                aiRouter.routeImageGeneration(
                                                    jobId = job.id,
                                                    prompt = job.prompt,
                                                    settings = ImageGenerationSettings(
                                                        aspectRatio = job.aspectRatio,
                                                        quality = job.quality,
                                                        style = job.style,
                                                        projectId = job.projectId,
                                                        tier = _selectedTier.value
                                                    ),
                                                    customRequestId = job.requestId,
                                                    targetMode = ImageGenerationMode.MOCK
                                                )
                                            }
                                            if (resp.success && resp.data != null) {
                                                resolvedImageUrl = resp.data.imageUrl
                                                resolvedProviderName = resp.providerName
                                                resolvedEstimatedCost = resp.estimatedCostUsd
                                            }
                                            if (job.projectId != null) {
                                                incrementProjectImageCount(job.projectId)
                                            }
                                        }
                                        JobType.VIDEO -> {
                                            val resp = runBlocking {
                                                aiRouter.routeVideoGeneration(
                                                    jobId = job.id,
                                                    prompt = job.prompt,
                                                    settings = VideoGenerationSettings(
                                                        duration = job.duration,
                                                        aspectRatio = job.aspectRatio,
                                                        quality = job.quality,
                                                        style = job.style,
                                                        tier = _selectedTier.value
                                                    )
                                                )
                                            }
                                            if (resp.success && resp.data != null) {
                                                resolvedProviderName = resp.providerName
                                                resolvedEstimatedCost = resp.estimatedCostUsd
                                            }
                                        }
                                        JobType.VOICE -> {
                                            val resp = runBlocking {
                                                aiRouter.routeVoiceGeneration(
                                                    jobId = job.id,
                                                    text = job.voiceScript ?: job.prompt,
                                                    config = VoiceConfig(
                                                        language = "Hindi / English",
                                                        voiceName = job.voiceSpeaker ?: "Dev (Narrator)",
                                                        gender = "Male",
                                                        style = job.style
                                                    ),
                                                    tier = _selectedTier.value
                                                )
                                            }
                                            if (resp.success && resp.data != null) {
                                                resolvedProviderName = resp.providerName
                                                resolvedEstimatedCost = resp.estimatedCostUsd
                                            }
                                        }
                                    }

                                    job.copy(
                                        status = JobStatus.COMPLETED,
                                        progress = 100,
                                        completedAt = System.currentTimeMillis(),
                                        imageUrl = resolvedImageUrl,
                                        providerName = resolvedProviderName,
                                        estimatedCostUsd = resolvedEstimatedCost
                                    )
                                }
                            } else {
                                job.copy(progress = nextProgress)
                            }
                        }
                    } else job
                }
            }
        }
    }

    fun incrementProjectImageCount(projectId: String, count: Int = 1) {
        _projects.value = _projects.value.map { project ->
            if (project.id == projectId) {
                project.copy(imageCount = project.imageCount + count)
            } else project
        }
    }

    fun regenerateJob(jobId: String) {
        _jobs.value = _jobs.value.map { job ->
            if (job.id == jobId) {
                job.copy(status = JobStatus.WAITING, progress = 0, completedAt = null, error = null)
            } else job
        }
        startQueueRunner()
    }

    fun retryJob(jobId: String) {
        val targetJob = _jobs.value.find { it.id == jobId } ?: return
        
        // Re-reserve credits if this is a Replicate job with creditsCharged
        if (targetJob.creditsCharged > 0) {
            if (_credits.value < targetJob.creditsCharged) {
                return // Not enough credits to re-attempt
            }
            _credits.value -= targetJob.creditsCharged
            _transactions.value = listOf(
                CreditTransaction(
                    id = "tx-retry-${System.currentTimeMillis()}",
                    type = "Retry Debit",
                    amount = -targetJob.creditsCharged,
                    description = "Re-reserved ${targetJob.creditsCharged} credits for job retry: ${targetJob.jobNumber}",
                    timestamp = dateFormat.format(Date())
                )
            ) + _transactions.value
        }

        _jobs.value = _jobs.value.map { job ->
            if (job.id == jobId) {
                val cleanPrompt = job.prompt
                    .replace("fail", "scenic", ignoreCase = true)
                    .replace("error", "vibrant", ignoreCase = true)
                job.copy(
                    prompt = cleanPrompt,
                    status = JobStatus.WAITING,
                    progress = 0,
                    completedAt = null,
                    error = null,
                    requestId = "req-img-${System.currentTimeMillis()}-${(1000..9999).random()}"
                )
            } else job
        }
        startQueueRunner()
    }

    fun cancelJob(jobId: String) {
        val target = _jobs.value.find { it.id == jobId } ?: return
        if (target.status == JobStatus.WAITING || target.status == JobStatus.SUBMITTING) {
            // Refund reserved credits
            if (target.creditsCharged > 0) {
                _credits.value += target.creditsCharged
                _transactions.value = listOf(
                    CreditTransaction(
                        id = "tx-cancel-${System.currentTimeMillis()}",
                        type = "Cancellation Refund",
                        amount = target.creditsCharged,
                        description = "Refunded ${target.creditsCharged} credits for cancelled job ${target.jobNumber}",
                        timestamp = dateFormat.format(Date())
                    )
                ) + _transactions.value
            }
            _jobs.value = _jobs.value.map { job ->
                if (job.id == jobId) {
                    job.copy(status = JobStatus.CANCELLED, error = "Cancelled by user.")
                } else job
            }
        }
    }

    fun retryAllFailedJobs(type: JobType? = null) {
        _jobs.value = _jobs.value.map { job ->
            if (job.status == JobStatus.FAILED && (type == null || job.type == type)) {
                val cleanPrompt = job.prompt
                    .replace("fail", "scenic", ignoreCase = true)
                    .replace("error", "vibrant", ignoreCase = true)
                job.copy(prompt = cleanPrompt, status = JobStatus.WAITING, progress = 0, completedAt = null, error = null)
            } else job
        }
        startQueueRunner()
    }

    fun clearCompletedJobs(type: JobType? = null) {
        _jobs.value = _jobs.value.filterNot {
            it.status == JobStatus.COMPLETED && (type == null || it.type == type)
        }
    }

    fun clearAllImageJobs() {
        _jobs.value = _jobs.value.filter { it.type != JobType.IMAGE }
    }

    fun deleteJob(jobId: String) {
        _jobs.value = _jobs.value.filter { it.id != jobId }
    }

    fun clearAllJobs() {
        _jobs.value = emptyList()
    }

    fun topUpCredits(amount: Int) {
        _credits.value += amount
        val timeStr = dateFormat.format(Date())
        _transactions.value = listOf(
            CreditTransaction(
                id = "tx-${System.currentTimeMillis()}",
                type = "Credit Top-Up",
                amount = amount,
                description = "Purchased credit top-up package",
                timestamp = timeStr
            )
        ) + _transactions.value
    }

    fun createProject(name: String, type: String): SaaSProject {
        val proj = SaaSProject(
            id = "proj-${System.currentTimeMillis()}",
            name = name,
            type = type,
            sceneCount = 0,
            videoCount = 0,
            imageCount = 0,
            createdAt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            status = "Active"
        )
        _projects.value = listOf(proj) + _projects.value
        return proj
    }

    fun deleteProject(id: String) {
        _projects.value = _projects.value.filter { it.id != id }
    }

    fun duplicateProject(id: String) {
        val proj = _projects.value.find { it.id == id } ?: return
        val dup = proj.copy(
            id = "proj-${System.currentTimeMillis()}",
            name = "${proj.name} (Copy)"
        )
        _projects.value = listOf(dup) + _projects.value
    }

    fun renameProject(id: String, newName: String) {
        _projects.value = _projects.value.map {
            if (it.id == id) it.copy(name = newName) else it
        }
    }

    fun generateDocumentaryScript(topic: String, sceneCount: Int, language: String) {
        scope.launch {
            _isGeneratingScript.value = true
            delay(1500) // Simulate intelligent script formulation

            val scenes = mutableListOf<DocumentaryScene>()
            val isHindi = language.contains("Hindi", ignoreCase = true)

            val titlesHindi = listOf(
                "प्रस्तावना: शहर की धड़कन और सुबह का आगाज़",
                "ऐतिहासिक विरासत और सदियों पुरानी वास्तुकला",
                "आधुनिक महानगर और गगनचुंबी इमारतें",
                "भीड़भाड़ वाले पारंपरिक बाजार और स्थानीय संस्कृति",
                "प्रौद्योगिकी और नवाचार का केंद्र",
                "नदी तट और प्राकृतिक मनोरम दृश्य",
                "शहरी जीवनशैली और युवाओं की ऊर्जा",
                "रात्रि का विहंगम दृश्य और जगमगाती सड़कें",
                "आर्थिक राजधानी और व्यापारिक केंद्र",
                "भविष्य की ओर अग्रसर नया भारत"
            )

            val titlesEnglish = listOf(
                "Prologue: Sunrise Over the Awakening Metropolis",
                "Centuries of Heritage & Ancient Architecture",
                "Modern Megacity: Soaring Skylines & Transit",
                "Bustling Historic Bazaars & Cultural Tapestry",
                "Technology, Innovation & Research Hubs",
                "Riverside Ghats & Sacred Waterfronts",
                "Urban Pulse: Vibrant Youth & Creative Culture",
                "Illuminated Night Skyline & Golden Highways",
                "Economic Engine & Financial District",
                "Epilogue: The Future Vision of Tomorrow"
            )

            val titles = if (isHindi) titlesHindi else titlesEnglish

            for (i in 1..sceneCount) {
                val titleIndex = (i - 1) % titles.size
                val baseTitle = titles[titleIndex]
                val sceneTitle = "Scene $i: $baseTitle"

                val prompt = if (isHindi) {
                    "Realistic cinematic 4K drone shot of ${topic.take(30)} with morning golden hour lighting, 8k resolution, photorealistic atmosphere, cinematic depth of field."
                } else {
                    "Cinematic aerial drone shot capturing ${topic.take(30)}, soaring perspective, golden sunrise volumetric lighting, documentary realism."
                }

                val voiceOver = if (isHindi) {
                    "दृश्य $i: $topic की इस अनूठी गाथा में, हम देखते हैं कि कैसे यह धरती सदियों के इतिहास और आधुनिक प्रगति का अद्भुत संगम प्रस्तुत करती है..."
                } else {
                    "Scene $i: In this grand chapter of $topic, we witness a breathtaking tapestry of ancient heritage harmoniously woven into a thriving modern future..."
                }

                scenes.add(
                    DocumentaryScene(
                        sceneNumber = i,
                        title = sceneTitle,
                        videoPrompt = prompt,
                        voiceOverText = voiceOver,
                        durationSec = 8,
                        shotType = "Cinematic Drone 4K"
                    )
                )
            }

            val scriptTitle = if (isHindi) "महागाथा: $topic" else "Documentary Chronicles: $topic"
            val scriptIntro = if (isHindi) {
                "भारत की गौरवशाली संस्कृति, ऐतिहासिक स्मारकों और आधुनिक विकास की एक महाकाव्य यात्रा।"
            } else {
                "A captivating visual and auditory journey exploring the rich contrasts, history, and dynamism of $topic."
            }

            _currentScript.value = DocumentaryScript(
                topic = topic,
                title = scriptTitle,
                introduction = scriptIntro,
                language = language,
                scenes = scenes
            )
            _isGeneratingScript.value = false
        }
    }

    fun exportScenesToBulkVideo(script: DocumentaryScript) {
        val prompts = script.scenes.map { it.videoPrompt }
        addBulkVideoJobs(
            prompts = prompts,
            duration = "8 seconds",
            aspectRatio = "16:9",
            quality = "High",
            style = "Documentary",
            tier = _selectedTier.value
        )
    }

    fun cleanPromptText(text: String): String {
        return text.trim()
            .replace(Regex("^(?:Prompt\\s*\\d*[:.]?\\s*|\\d+[:.]?\\s*)", RegexOption.IGNORE_CASE), "")
            .trim()
    }

    fun parseBulkPrompts(input: String): List<String> {
        val lines = input.split("\n", "\r\n")
        val parsed = mutableListOf<String>()
        var currentPrompt = StringBuilder()

        val hasNumberedHeaders = lines.any {
            it.trim().matches(Regex("^(?:Prompt\\s*\\d+[:.]?|\\d+[:.]).*$", RegexOption.IGNORE_CASE))
        }

        if (hasNumberedHeaders) {
            for (line in lines) {
                val trimmed = line.trim()
                if (trimmed.isEmpty()) {
                    if (currentPrompt.isNotEmpty()) {
                        parsed.add(currentPrompt.toString().trim())
                        currentPrompt = StringBuilder()
                    }
                    continue
                }

                val isHeader = trimmed.matches(Regex("^(?:Prompt\\s*\\d+[:.]?|\\d+[:.]).*$", RegexOption.IGNORE_CASE))
                if (isHeader) {
                    if (currentPrompt.isNotEmpty()) {
                        parsed.add(currentPrompt.toString().trim())
                        currentPrompt = StringBuilder()
                    }
                    currentPrompt.append(cleanPromptText(trimmed))
                } else {
                    if (currentPrompt.isNotEmpty()) {
                        currentPrompt.append(" ").append(trimmed)
                    } else {
                        currentPrompt.append(trimmed)
                    }
                }
            }
            if (currentPrompt.isNotEmpty()) {
                parsed.add(currentPrompt.toString().trim())
            }
        } else {
            val hasBlankLines = lines.any { it.trim().isEmpty() }
            if (hasBlankLines) {
                for (line in lines) {
                    val trimmed = line.trim()
                    if (trimmed.isEmpty()) {
                        if (currentPrompt.isNotEmpty()) {
                            parsed.add(currentPrompt.toString().trim())
                            currentPrompt = StringBuilder()
                        }
                    } else {
                        if (currentPrompt.isNotEmpty()) {
                            currentPrompt.append(" ").append(trimmed)
                        } else {
                            currentPrompt.append(trimmed)
                        }
                    }
                }
                if (currentPrompt.isNotEmpty()) {
                    parsed.add(currentPrompt.toString().trim())
                }
            } else {
                for (line in lines) {
                    val clean = cleanPromptText(line)
                    if (clean.isNotBlank()) {
                        parsed.add(clean)
                    }
                }
            }
        }

        return parsed.filter { it.isNotBlank() }
    }

    fun parseCsvPrompts(csvText: String): List<String> {
        val lines = csvText.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList()

        val headerLine = lines.first()
        val headers = parseCsvRow(headerLine).map { it.lowercase().trim().trim('\"') }
        val promptColIndex = headers.indexOfFirst { it == "prompt" || it.contains("prompt") }

        val dataLines = lines.drop(1)
        if (promptColIndex != -1 && dataLines.isNotEmpty()) {
            val results = mutableListOf<String>()
            for (line in dataLines) {
                val columns = parseCsvRow(line)
                if (promptColIndex < columns.size) {
                    val value = columns[promptColIndex].trim().trim('\"').trim()
                    if (value.isNotEmpty()) {
                        results.add(value)
                    }
                }
            }
            if (results.isNotEmpty()) return results
        }

        // Fallback: If no column named 'prompt' found in header, check first column
        val fallbackResults = mutableListOf<String>()
        for (line in lines) {
            val columns = parseCsvRow(line)
            if (columns.isNotEmpty()) {
                val first = columns[0].trim().trim('\"').trim()
                if (first.isNotEmpty() && !first.equals("prompt", ignoreCase = true)) {
                    fallbackResults.add(first)
                }
            }
        }
        return fallbackResults
    }

    fun parseTxtPrompts(txtText: String): List<String> {
        return txtText.lines()
            .map { cleanPromptText(it.trim()) }
            .filter { it.isNotBlank() }
    }

    private fun parseCsvRow(line: String): List<String> {
        val tokens = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false
        for (ch in line) {
            if (ch == '\"') {
                inQuotes = !inQuotes
            } else if (ch == ',' && !inQuotes) {
                tokens.add(sb.toString())
                sb.setLength(0)
            } else {
                sb.append(ch)
            }
        }
        tokens.add(sb.toString())
        return tokens
    }

    fun getSamplePrompts(): List<String> {
        return listOf(
            "A hyper-realistic aerial photography of ancient Indian stone temple at sunrise.",
            "Cinematic portrait of a majestic royal Bengal tiger in morning mist of Jim Corbett.",
            "Vibrant traditional Holi festival celebration in Vrindavan with swirling powder colors.",
            "Futuristic cyber-metropolis of Mumbai year 2099 with flying vehicles and neon skyline.",
            "Serene wooden houseboat cruising through emerald backwaters of Alleppey Kerala.",
            "Golden sunset over ancient sandstone desert fort in Jaisalmer with camel caravan.",
            "Documentary close-up portrait of an Indian artisan carving intricate marble in Agra.",
            "Himalayan monastery perched on snow-capped mountain ridge under Milky Way galaxy.",
            "Traditional Kathakali classical dancer in ornate costume and expressive eye makeup.",
            "Spectacular cascading Athirappilly waterfalls surrounded by lush monsoon rainforest."
        )
    }

    fun getSampleCsvContent(): String {
        return "prompt,aspect_ratio,style\n" +
                "\"A hyper-realistic aerial photography of ancient Indian stone temple at sunrise.\",16:9,Realistic\n" +
                "\"Cinematic portrait of a majestic royal Bengal tiger in morning mist of Jim Corbett.\",1:1,Cinematic\n" +
                "\"Vibrant traditional Holi festival celebration in Vrindavan with swirling powder colors.\",1:1,Cinematic\n" +
                "\"Futuristic cyber-metropolis of Mumbai year 2099 with flying vehicles and neon skyline.\",16:9,3D\n" +
                "\"Serene wooden houseboat cruising through emerald backwaters of Alleppey Kerala.\",16:9,Realistic\n" +
                "\"Golden sunset over ancient sandstone desert fort in Jaisalmer with camel caravan.\",16:9,Historical\n" +
                "\"Documentary close-up portrait of an Indian artisan carving intricate marble in Agra.\",4:5,Documentary\n" +
                "\"Himalayan monastery perched on snow-capped mountain ridge under Milky Way galaxy.\",16:9,Cinematic\n" +
                "\"Traditional Kathakali classical dancer in ornate costume and expressive eye makeup.\",4:5,Illustration\n" +
                "\"Spectacular cascading Athirappilly waterfalls surrounded by lush monsoon rainforest.\",9:16,Realistic"
    }

    fun getSampleTxtContent(): String {
        return "A hyper-realistic aerial photography of ancient Indian stone temple at sunrise.\n" +
                "Cinematic portrait of a majestic royal Bengal tiger in morning mist of Jim Corbett.\n" +
                "Vibrant traditional Holi festival celebration in Vrindavan with swirling powder colors.\n" +
                "Futuristic cyber-metropolis of Mumbai year 2099 with flying vehicles and neon skyline.\n" +
                "Serene wooden houseboat cruising through emerald backwaters of Alleppey Kerala.\n" +
                "Golden sunset over ancient sandstone desert fort in Jaisalmer with camel caravan.\n" +
                "Documentary close-up portrait of an Indian artisan carving intricate marble in Agra.\n" +
                "Himalayan monastery perched on snow-capped mountain ridge under Milky Way galaxy.\n" +
                "Traditional Kathakali classical dancer in ornate costume and expressive eye makeup.\n" +
                "Spectacular cascading Athirappilly waterfalls surrounded by lush monsoon rainforest."
    }

    // Admin panel user controls
    fun toggleBlockUser(userId: String) {
        _adminUsers.value = _adminUsers.value.map { user ->
            if (user.id == userId) user.copy(isBlocked = !user.isBlocked) else user
        }
    }

    fun adjustUserCredits(userId: String, delta: Int) {
        _adminUsers.value = _adminUsers.value.map { user ->
            if (user.id == userId) user.copy(credits = (user.credits + delta).coerceAtLeast(0)) else user
        }
    }

    companion object {
        @Volatile
        private var instance: BulkAiRepository? = null

        fun getInstance(): BulkAiRepository {
            return instance ?: synchronized(this) {
                instance ?: BulkAiRepository().also { instance = it }
            }
        }
    }
}
