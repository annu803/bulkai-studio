package com.example.data

import com.example.model.ModelTier

data class ImageGenerationSettings(
    val aspectRatio: String = "1:1",
    val quality: String = "High",
    val style: String = "Cinematic",
    val tier: ModelTier = ModelTier.STANDARD,
    val projectId: String? = null,
    val imagesPerPrompt: Int = 1
)

data class ImageGenerationResult(
    val success: Boolean,
    val imageUrl: String? = null,
    val prompt: String,
    val resolution: String = "1024x1024",
    val error: String? = null
)

interface ImageGenerationService {
    suspend fun generateImage(prompt: String, settings: ImageGenerationSettings): ImageGenerationResult
}

class MockImageGenerationService : ImageGenerationService {

    override suspend fun generateImage(
        prompt: String,
        settings: ImageGenerationSettings
    ): ImageGenerationResult {
        val lower = prompt.lowercase()

        val resolution = when (settings.aspectRatio) {
            "16:9" -> if (settings.quality == "High") "3840x2160 (4K)" else "1920x1080 (FHD)"
            "9:16" -> if (settings.quality == "High") "2160x3840 (4K)" else "1080x1920 (FHD)"
            "4:5" -> if (settings.quality == "High") "2160x2700 (High-Res)" else "1080x1350 (Social)"
            else -> if (settings.quality == "High") "2048x2048 (UHD)" else "1024x1024 (Standard)"
        }

        // Realistic themed mock imagery based on prompt semantics
        val url = when {
            lower.contains("temple") || lower.contains("kedarnath") || lower.contains("mandir") || lower.contains("ancient") || lower.contains("ghat") ->
                "https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=800&q=80"
            lower.contains("tiger") || lower.contains("wildlife") || lower.contains("animal") || lower.contains("forest") ->
                "https://images.unsplash.com/photo-1534188753412-3e26d0d618d6?auto=format&fit=crop&w=800&q=80"
            lower.contains("himalaya") || lower.contains("mountain") || lower.contains("snow") || lower.contains("glacier") ->
                "https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80"
            lower.contains("river") || lower.contains("flood") || lower.contains("valley") || lower.contains("rain") ->
                "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80"
            lower.contains("holi") || lower.contains("festival") || lower.contains("color") ->
                "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=800&q=80"
            lower.contains("palace") || lower.contains("fort") || lower.contains("rajasthan") || lower.contains("jaisalmer") ->
                "https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=800&q=80"
            lower.contains("cyber") || lower.contains("mumbai") || lower.contains("neon") || lower.contains("futuristic") ->
                "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=800&q=80"
            lower.contains("houseboat") || lower.contains("kerala") || lower.contains("backwaters") ->
                "https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=800&q=80"
            lower.contains("portrait") || lower.contains("person") || lower.contains("artisan") || lower.contains("face") ->
                "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80"
            lower.contains("3d") || lower.contains("render") || lower.contains("abstract") ->
                "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80"
            else ->
                "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80"
        }

        return ImageGenerationResult(
            success = true,
            imageUrl = url,
            prompt = prompt,
            resolution = resolution
        )
    }
}
