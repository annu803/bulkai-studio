package com.example.data.providers

/**
 * Centralized Provider & Model Pricing and Configuration.
 * Separates commercial AI provider pricing and credit multipliers from business logic
 * so pricing can be tuned dynamically without altering core workflow algorithms.
 */
object AiProviderPricingConfig {

    // Replicate Cost References (USD per successful output generation)
    const val REPLICATE_ECONOMY_MODEL = "minimax/image-01"
    const val REPLICATE_ECONOMY_COST_USD = 0.01

    const val REPLICATE_PREMIUM_MODEL = "google/imagen-4"
    const val REPLICATE_PREMIUM_COST_USD = 0.04

    // Mock Mode Cost References (Simulated)
    const val MOCK_IMAGE_ECONOMY_COST_USD = 0.002
    const val MOCK_IMAGE_STANDARD_COST_USD = 0.005
    const val MOCK_IMAGE_PREMIUM_COST_USD = 0.015

    // Configurable Credit Costs (SaaS in-app currency)
    var economyImageCredits: Int = 3
    var standardImageCredits: Int = 5
    var premiumImageCredits: Int = 8

    /**
     * Resolves credit cost for a given mode and quality setting
     */
    fun getCreditCost(mode: ImageGenerationMode, quality: String): Int {
        val base = when (mode) {
            ImageGenerationMode.MOCK -> if (quality == "High") 5 else 3
            ImageGenerationMode.REPLICATE_ECONOMY -> economyImageCredits
            ImageGenerationMode.REPLICATE_PREMIUM -> premiumImageCredits
        }
        return base
    }

    /**
     * Resolves estimated provider cost in USD
     */
    fun getEstimatedProviderCostUsd(mode: ImageGenerationMode): Double {
        return when (mode) {
            ImageGenerationMode.MOCK -> MOCK_IMAGE_STANDARD_COST_USD
            ImageGenerationMode.REPLICATE_ECONOMY -> REPLICATE_ECONOMY_COST_USD
            ImageGenerationMode.REPLICATE_PREMIUM -> REPLICATE_PREMIUM_COST_USD
        }
    }
}

/**
 * Selectable image generation modes
 */
enum class ImageGenerationMode(val displayName: String, val providerName: String, val modelIdentifier: String) {
    MOCK("Mock Mode", "Mock", "FastFlux / SDXL (Simulated)"),
    REPLICATE_ECONOMY("Economy (Replicate)", "Replicate", AiProviderPricingConfig.REPLICATE_ECONOMY_MODEL),
    REPLICATE_PREMIUM("Premium (Replicate)", "Replicate", AiProviderPricingConfig.REPLICATE_PREMIUM_MODEL)
}
