package com.example.data.providers

import com.example.model.ProviderStatus

/**
 * Common configuration passed to all AI generation requests.
 * Encapsulates unique request tracking, idempotency, timeout policies,
 * and cost tracking hooks.
 */
data class ProviderRequest(
    val requestId: String = "req-${System.currentTimeMillis()}-${(1000..9999).random()}",
    val jobId: String,
    val prompt: String,
    val timeoutMillis: Long = 30000L,
    val maxRetries: Int = 3,
    val metadata: Map<String, String> = emptyMap()
)

/**
 * Standardized result returned by all generation providers.
 * Includes output URL, metadata, error diagnostics, and estimated API compute costs.
 */
data class ProviderResponse<T>(
    val success: Boolean,
    val requestId: String,
    val jobId: String,
    val data: T? = null,
    val error: String? = null,
    val retryCount: Int = 0,
    val durationMillis: Long = 0L,
    val estimatedCostUsd: Double = 0.0,
    val providerName: String = "Mock",
    val modelName: String = ""
)

/**
 * Base abstraction interface implemented by all AI modality providers
 * (Image, Video, Voice/TTS, Script).
 *
 * Each provider supports:
 *  - getStatus()
 *  - handleError()
 */
interface BaseAiProvider {
    val providerId: String
    val providerName: String
    val supportedModels: List<String>
    
    /**
     * Checks provider availability: MOCK, CONFIGURED (API keys present), or UNAVAILABLE.
     */
    fun getStatus(): ProviderStatus
    
    /**
     * Centralized error mapping and recovery strategy.
     */
    fun handleError(throwable: Throwable, requestId: String): String
}
