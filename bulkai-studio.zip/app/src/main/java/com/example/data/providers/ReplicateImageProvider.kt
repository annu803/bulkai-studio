package com.example.data.providers

import android.util.Log
import com.example.BuildConfig
import com.example.data.ImageGenerationSettings
import com.example.model.ProviderStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Server-Side Image Generation Service for Replicate.
 *
 * Security:
 * - Reads API token strictly through BuildConfig.REPLICATE_API_TOKEN.
 * - Never returns, logs, or transmits the secret token to the UI.
 * - Handles asynchronous prediction submission, polling, timeout, error mapping, and result retrieval.
 */
class ReplicateImageProvider(
    private val modelType: ImageGenerationMode = ImageGenerationMode.REPLICATE_ECONOMY
) : ImageProvider {

    override val providerId: String = when (modelType) {
        ImageGenerationMode.REPLICATE_ECONOMY -> "provider-replicate-economy"
        ImageGenerationMode.REPLICATE_PREMIUM -> "provider-replicate-premium"
        else -> "provider-replicate-custom"
    }

    override val providerName: String = "Replicate"

    override val supportedModels: List<String> = listOf(
        AiProviderPricingConfig.REPLICATE_ECONOMY_MODEL,
        AiProviderPricingConfig.REPLICATE_PREMIUM_MODEL
    )

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    companion object {
        /**
         * Safely resolves the server-side AI Studio Secret named REPLICATE_API_TOKEN at runtime.
         * Prioritizes server-side runtime environment injection (System.getenv), then BuildConfig,
         * and guarantees that masked display values containing asterisks are never read or used.
         */
        fun resolveServerToken(): String {
            val envToken = try {
                System.getenv("REPLICATE_API_TOKEN")?.trim()
            } catch (e: Throwable) {
                null
            }
            if (!envToken.isNullOrBlank() &&
                !isTokenMaskedPlaceholder(envToken) &&
                !envToken.equals("DEFAULT_REPLICATE_API_TOKEN", ignoreCase = true) &&
                !envToken.equals("YOUR_REPLICATE_API_TOKEN", ignoreCase = true)
            ) {
                return envToken
            }

            val buildConfigToken = try {
                val field = BuildConfig::class.java.getField("REPLICATE_API_TOKEN")
                val value = field.get(null) as? String ?: ""
                val clean = value.trim()
                if (isTokenMaskedPlaceholder(clean) ||
                    clean.equals("DEFAULT_REPLICATE_API_TOKEN", ignoreCase = true) ||
                    clean.equals("YOUR_REPLICATE_API_TOKEN", ignoreCase = true)
                ) {
                    ""
                } else {
                    clean
                }
            } catch (e: Throwable) {
                ""
            }

            return buildConfigToken
        }

        fun isTokenMaskedPlaceholder(token: String?): Boolean {
            return token != null && token.contains("*")
        }

        fun isValidReplicateToken(token: String?): Boolean {
            return !token.isNullOrBlank() && !isTokenMaskedPlaceholder(token) && token.startsWith("r8_")
        }
    }

    /**
     * Resolves the actual server-side token at runtime.
     * Never returns masked or display placeholder values.
     */
    fun getApiToken(): String {
        return resolveServerToken()
    }

    /**
     * Checks provider availability:
     * - CONFIGURED if valid unmasked REPLICATE_API_TOKEN is present.
     * - UNAVAILABLE if no valid token is configured.
     */
    override fun getStatus(): ProviderStatus {
        val token = getApiToken()
        return if (isValidReplicateToken(token)) {
            ProviderStatus.CONFIGURED
        } else {
            ProviderStatus.UNAVAILABLE
        }
    }

    /**
     * Standard error handler that santizes messages and masks secrets.
     */
    override fun handleError(throwable: Throwable, requestId: String): String {
        val raw = throwable.message ?: "Unknown error"
        val token = getApiToken()
        val sanitized = if (token.isNotBlank()) raw.replace(token, "[REDACTED_API_TOKEN]") else raw
        return when {
            sanitized.contains("401", ignoreCase = true) || sanitized.contains("unauthenticated", ignoreCase = true) ->
                "Invalid Replicate API token (401). Please verify that REPLICATE_API_TOKEN in the AI Studio Secrets panel contains your unmasked Replicate API key (starts with r8_)."
            sanitized.contains("429", ignoreCase = true) || sanitized.contains("rate limit", ignoreCase = true) ->
                "Replicate API rate limit exceeded. Please wait a moment before trying again."
            sanitized.contains("NSFW", ignoreCase = true) || sanitized.contains("sensitive content", ignoreCase = true) || sanitized.contains("safety", ignoreCase = true) ->
                "Generation rejected by safety / content moderation filters."
            sanitized.contains("timed out", ignoreCase = true) || sanitized.contains("timeout", ignoreCase = true) ->
                "Replicate prediction timed out while waiting for GPU worker."
            sanitized.contains("Unable to resolve host", ignoreCase = true) || sanitized.contains("Failed to connect", ignoreCase = true) ->
                "Network error connecting to Replicate API. Check internet connectivity."
            else -> sanitized
        }
    }

    /**
     * Maps UI aspect ratios and quality to model-compatible parameters.
     */
    private fun mapSettingsToInput(
        prompt: String,
        settings: ImageGenerationSettings,
        modelName: String
    ): JSONObject {
        val inputJson = JSONObject()
        inputJson.put("prompt", prompt)

        if (modelName.contains("minimax", ignoreCase = true)) {
            // Minimax image-01 parameter mapping
            val mappedAspect = when (settings.aspectRatio) {
                "16:9" -> "16:9"
                "9:16" -> "9:16"
                "4:5" -> "4:5"
                else -> "1:1"
            }
            inputJson.put("aspect_ratio", mappedAspect)
        } else if (modelName.contains("imagen-4", ignoreCase = true)) {
            // Google Imagen 4 parameter mapping
            val mappedAspect = when (settings.aspectRatio) {
                "16:9" -> "16:9"
                "9:16" -> "9:16"
                "4:5" -> "4:5"
                else -> "1:1"
            }
            inputJson.put("aspect_ratio", mappedAspect)
            if (settings.quality == "High") {
                inputJson.put("output_format", "png")
            } else {
                inputJson.put("output_format", "jpg")
            }
        } else {
            // Generic fallback
            inputJson.put("aspect_ratio", settings.aspectRatio)
        }

        return inputJson
    }

    /**
     * Executes real Replicate image generation via Prediction API:
     * 1. Check API token
     * 2. POST https://api.replicate.com/v1/models/{model}/predictions
     * 3. Poll GET prediction endpoint until status is 'succeeded' or 'failed'
     * 4. Return synthesized image URL and cost metrics
     */
    override suspend fun generate(
        request: ProviderRequest,
        settings: ImageGenerationSettings
    ): ProviderResponse<ImageOutput> = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val token = getApiToken()

        if (!isValidReplicateToken(token)) {
            return@withContext ProviderResponse(
                success = false,
                requestId = request.requestId,
                jobId = request.jobId,
                error = "Real image generation is not configured. Valid unmasked REPLICATE_API_TOKEN secret is required in AI Studio Secrets.",
                providerName = providerName,
                modelName = modelType.modelIdentifier
            )
        }

        val targetModel = modelType.modelIdentifier
        val estimatedCost = when (modelType) {
            ImageGenerationMode.REPLICATE_ECONOMY -> AiProviderPricingConfig.REPLICATE_ECONOMY_COST_USD
            ImageGenerationMode.REPLICATE_PREMIUM -> AiProviderPricingConfig.REPLICATE_PREMIUM_COST_USD
            else -> AiProviderPricingConfig.REPLICATE_ECONOMY_COST_USD
        }

        try {
            // Step 1: Create prediction
            val inputJson = mapSettingsToInput(request.prompt, settings, targetModel)
            val requestBodyJson = JSONObject().apply {
                put("input", inputJson)
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = requestBodyJson.toString().toRequestBody(mediaType)

            // Replicate model prediction URL: https://api.replicate.com/v1/models/{owner}/{name}/predictions
            val endpointUrl = "https://api.replicate.com/v1/models/$targetModel/predictions"

            val initialRequest = Request.Builder()
                .url(endpointUrl)
                .header("Authorization", "Bearer $token")
                .header("Content-Type", "application/json")
                .header("Prefer", "wait=5") // Ask Replicate to wait up to 5s to complete synchronously if fast
                .post(body)
                .build()

            val response = httpClient.newCall(initialRequest).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errorMsg = try {
                    val errJson = JSONObject(responseBody)
                    errJson.optString("detail", "HTTP ${response.code}: $responseBody")
                } catch (_: Exception) {
                    "HTTP ${response.code}: $responseBody"
                }
                return@withContext ProviderResponse(
                    success = false,
                    requestId = request.requestId,
                    jobId = request.jobId,
                    error = handleError(IOException(errorMsg), request.requestId),
                    providerName = providerName,
                    modelName = targetModel,
                    durationMillis = System.currentTimeMillis() - startTime
                )
            }

            val predictionJson = JSONObject(responseBody)
            val predictionId = predictionJson.optString("id")
            var status = predictionJson.optString("status") // starting, processing, succeeded, failed, canceled
            val pollUrl = predictionJson.optJSONObject("urls")?.optString("get")
                ?: "https://api.replicate.com/v1/predictions/$predictionId"

            val maxPollDurationMs = 120000L // 2 minutes max
            val pollIntervalMs = 2500L
            var currentPollJson = predictionJson

            // Step 2: Poll status if not already finished
            while (status != "succeeded" && status != "failed" && status != "canceled") {
                if (System.currentTimeMillis() - startTime > maxPollDurationMs) {
                    return@withContext ProviderResponse(
                        success = false,
                        requestId = request.requestId,
                        jobId = request.jobId,
                        error = "Prediction timed out after 120 seconds on Replicate GPU cluster.",
                        providerName = providerName,
                        modelName = targetModel,
                        durationMillis = System.currentTimeMillis() - startTime
                    )
                }

                delay(pollIntervalMs)

                val pollReq = Request.Builder()
                    .url(pollUrl)
                    .header("Authorization", "Bearer $token")
                    .get()
                    .build()

                val pollResp = httpClient.newCall(pollReq).execute()
                val pollBody = pollResp.body?.string() ?: ""

                if (pollResp.isSuccessful) {
                    currentPollJson = JSONObject(pollBody)
                    status = currentPollJson.optString("status")
                } else {
                    Log.w("ReplicateProvider", "Poll warning: HTTP ${pollResp.code}")
                }
            }

            if (status == "succeeded") {
                // Parse output URL (can be string or array of strings)
                val imageUrl = extractImageUrl(currentPollJson)
                if (imageUrl.isNullOrBlank()) {
                    return@withContext ProviderResponse(
                        success = false,
                        requestId = request.requestId,
                        jobId = request.jobId,
                        error = "Generation succeeded but no image URL was returned by Replicate.",
                        providerName = providerName,
                        modelName = targetModel,
                        durationMillis = System.currentTimeMillis() - startTime
                    )
                }

                val resolution = when (settings.aspectRatio) {
                    "16:9" -> "1920x1080"
                    "9:16" -> "1080x1920"
                    "4:5" -> "1080x1350"
                    else -> "1024x1024"
                }

                return@withContext ProviderResponse(
                    success = true,
                    requestId = predictionId.ifBlank { request.requestId },
                    jobId = request.jobId,
                    data = ImageOutput(
                        imageUrl = imageUrl,
                        resolution = resolution,
                        prompt = request.prompt,
                        aspectRatio = settings.aspectRatio
                    ),
                    durationMillis = System.currentTimeMillis() - startTime,
                    estimatedCostUsd = estimatedCost,
                    providerName = "$providerName (${modelType.displayName})",
                    modelName = targetModel
                )
            } else {
                val failureDetail = currentPollJson.optString("error", "Prediction $status on provider")
                return@withContext ProviderResponse(
                    success = false,
                    requestId = predictionId.ifBlank { request.requestId },
                    jobId = request.jobId,
                    error = handleError(Exception(failureDetail), request.requestId),
                    providerName = providerName,
                    modelName = targetModel,
                    durationMillis = System.currentTimeMillis() - startTime
                )
            }

        } catch (e: Exception) {
            return@withContext ProviderResponse(
                success = false,
                requestId = request.requestId,
                jobId = request.jobId,
                error = handleError(e, request.requestId),
                providerName = providerName,
                modelName = targetModel,
                durationMillis = System.currentTimeMillis() - startTime
            )
        }
    }

    /**
     * Extracts output URL from Replicate response.
     * Replicate output can be a string URL, a JSON array of strings, or a dictionary.
     */
    private fun extractImageUrl(json: JSONObject): String? {
        val output = json.opt("output") ?: return null
        return when (output) {
            is String -> output
            is JSONArray -> if (output.length() > 0) output.optString(0) else null
            is JSONObject -> output.optString("image")
            else -> output.toString()
        }
    }
}
