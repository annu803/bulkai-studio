package com.example.model

enum class JobType {
    VIDEO,
    IMAGE,
    VOICE
}

enum class JobStatus {
    WAITING,
    SUBMITTING,
    PROCESSING,
    COMPLETED,
    FAILED,
    CANCELLED
}

enum class ModelTier(val displayName: String, val creditMultiplier: Int) {
    ECONOMY("Economy (Wan 2.1 / FastFlux)", 1),
    STANDARD("Standard (Kling v1.5 / SDXL)", 2),
    PREMIUM("Premium (Google Veo 2 / Gemini 2.0)", 4)
}

data class GenerationJob(
    val id: String,
    val jobNumber: String,
    val prompt: String,
    val type: JobType,
    val status: JobStatus = JobStatus.WAITING,
    val progress: Int = 0,
    val model: String = "Google Veo 2",
    val duration: String = "8 seconds",
    val aspectRatio: String = "16:9",
    val quality: String = "High",
    val style: String = "Cinematic",
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val error: String? = null,
    val previewAccentColor: Long = 0xFF1E3A8A,
    val voiceScript: String? = null,
    val voiceSpeaker: String? = null,
    val downloadUrl: String? = null,
    val imageUrl: String? = null,
    val projectId: String? = null,
    val requestId: String = "req-${System.currentTimeMillis()}-${(1000..9999).random()}",
    val providerName: String = "Mock",
    val mode: String = "MOCK",
    val estimatedCostUsd: Double = 0.0,
    val creditsCharged: Int = 0
)

data class SaaSProject(
    val id: String,
    val name: String,
    val type: String,
    val sceneCount: Int,
    val videoCount: Int,
    val imageCount: Int,
    val createdAt: String,
    val status: String = "Active"
)

data class DocumentaryScene(
    val sceneNumber: Int,
    val title: String,
    val videoPrompt: String,
    val voiceOverText: String,
    val durationSec: Int = 8,
    val shotType: String = "Cinematic Drone Shot"
)

data class DocumentaryScript(
    val topic: String,
    val title: String,
    val introduction: String,
    val language: String = "Hindi",
    val scenes: List<DocumentaryScene> = emptyList()
)

data class VoiceProfile(
    val id: String,
    val name: String,
    val language: String,
    val gender: String,
    val description: String
)

data class VoiceConfig(
    val language: String = "Hindi",
    val voiceName: String = "Aarav",
    val gender: String = "Male",
    val style: String = "Documentary",
    val speed: Float = 1.0f,
    val pitch: Float = 1.0f,
    val emotion: String = "Inspiring"
)

data class CreditTransaction(
    val id: String,
    val type: String,
    val amount: Int,
    val description: String,
    val timestamp: String,
    val status: String = "Completed"
)

data class PricingPlan(
    val id: String = "",
    val name: String,
    val priceMonthly: String,
    val priceAnnual: String,
    val creditsPerMonth: Int,
    val isPopular: Boolean = false,
    val features: List<String>
)

data class SaaSUser(
    val id: String,
    val name: String,
    val email: String,
    val plan: String,
    val credits: Int,
    val isBlocked: Boolean = false,
    val joinedDate: String = "2026-08-15"
)

enum class ProviderStatus(val displayName: String) {
    MOCK("Mock"),
    CONFIGURED("Configured"),
    UNAVAILABLE("Unavailable")
}

data class ProviderInfo(
    val category: String,
    val activeProviderName: String,
    val status: ProviderStatus,
    val modelName: String,
    val isMock: Boolean = true,
    val note: String = ""
)
