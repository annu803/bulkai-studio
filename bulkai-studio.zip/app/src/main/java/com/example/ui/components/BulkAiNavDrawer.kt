package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

enum class AppDestination(
    val title: String,
    val icon: ImageVector,
    val badge: String? = null
) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    BULK_VIDEO("Bulk Video", Icons.Default.VideoCall, "Fast"),
    BULK_IMAGE("Bulk Image", Icons.Default.Image, "New"),
    AI_SCRIPT("AI Script", Icons.Default.AutoStories),
    VOICE_OVER("Voice Over", Icons.Default.RecordVoiceOver),
    PROJECTS("Projects", Icons.Default.Folder),
    CREDITS("Credits", Icons.Default.Bolt),
    PRICING("Pricing", Icons.Default.Sell),
    ADMIN_PANEL("Admin Panel", Icons.Default.AdminPanelSettings),
    SETTINGS("Settings", Icons.Default.Tune)
}

@Composable
fun DrawerContent(
    currentDestination: AppDestination,
    onDestinationSelected: (AppDestination) -> Unit,
    credits: Int,
    isMockMode: Boolean,
    onToggleMockMode: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SaaSSurface,
        modifier = modifier
            .fillMaxHeight()
            .width(290.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // BulkAI Studio Brand Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF2563EB), Color(0xFF7C3AED))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Logo",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "BulkAI Studio",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Commercial AI Engine",
                        color = Color(0xFF38BDF8),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Divider(color = SaaSSurfaceBorder, thickness = 1.dp, modifier = Modifier.padding(vertical = 10.dp))

            // User Profile Card & Credits
            Surface(
                color = SaaSSurfaceCard,
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(
                        listOf(SaaSSurfaceBorder, Color(0xFF3B82F6).copy(alpha = 0.2f))
                    )
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onDestinationSelected(AppDestination.CREDITS) }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E3A8A)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "AS",
                            color = Color(0xFF93C5FD),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Amit Shukla",
                            color = TextPrimaryDark,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "⚡ $credits Credits",
                                color = Color(0xFFFBBF24),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Navigation Items
            Text(
                text = "STUDIO MODULES",
                color = TextMutedDark,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
            )

            AppDestination.values().forEach { destination ->
                val isSelected = currentDestination == destination
                Surface(
                    color = if (isSelected) Color(0xFF1E293B) else Color.Transparent,
                    shape = RoundedCornerShape(8.dp),
                    border = if (isSelected) CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0xFF3B82F6), Color(0xFF8B5CF6))
                        )
                    ) else null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .clickable { onDestinationSelected(destination) }
                        .testTag("nav_${destination.name.lowercase()}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Icon(
                            imageVector = destination.icon,
                            contentDescription = destination.title,
                            tint = if (isSelected) Color(0xFF60A5FA) else TextSecondaryDark,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = destination.title,
                            color = if (isSelected) Color.White else TextSecondaryDark,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                            modifier = Modifier.weight(1f)
                        )
                        if (destination.badge != null) {
                            Surface(
                                color = Color(0xFF1E3A8A),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = destination.badge,
                                    color = Color(0xFF93C5FD),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f, fill = false))
            Spacer(modifier = Modifier.height(16.dp))

            // Mock Mode status pill in footer
            Surface(
                color = SaaSSurfaceCard,
                shape = RoundedCornerShape(8.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(
                        listOf(SaaSSurfaceBorder, Color(0xFF10B981).copy(alpha = 0.3f))
                    )
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.padding(10.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (isMockMode) Color(0xFF10B981) else Color(0xFF3B82F6))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isMockMode) "MOCK MODE ACTIVE" else "LIVE API MODE",
                                color = if (isMockMode) Color(0xFF6EE7B7) else Color(0xFF93C5FD),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = if (isMockMode) "Zero API costs (offline)" else "Connected to AI endpoints",
                            color = TextMutedDark,
                            fontSize = 9.sp
                        )
                    }
                    Switch(
                        checked = isMockMode,
                        onCheckedChange = onToggleMockMode,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF059669),
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = Color(0xFF2563EB)
                        ),
                        modifier = Modifier.size(width = 44.dp, height = 24.dp)
                    )
                }
            }
        }
    }
}
