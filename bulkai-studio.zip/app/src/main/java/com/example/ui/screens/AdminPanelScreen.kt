package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BulkAiRepository
import com.example.model.ProviderInfo
import com.example.model.ProviderStatus
import com.example.ui.components.StatCard
import com.example.ui.theme.*

@Composable
fun AdminPanelScreen(
    repository: BulkAiRepository,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val adminUsers by repository.adminUsers.collectAsState()
    val jobs by repository.jobs.collectAsState()

    val totalVideos = 48210 + jobs.count { it.type == com.example.model.JobType.VIDEO }
    val totalImages = 142800 + jobs.count { it.type == com.example.model.JobType.IMAGE }
    val totalVoice = 28900 + jobs.count { it.type == com.example.model.JobType.VOICE }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp)
    ) {
        // Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "Admin SaaS Console",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "System metrics, GPU infrastructure costs and tenant controls",
                        color = TextSecondaryDark,
                        fontSize = 12.sp
                    )
                }

                Surface(
                    color = Color(0xFF881337),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "SUPERADMIN",
                        color = Color(0xFFFECDD3),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Top Financial & SaaS Stats
        item {
            Text(
                text = "COMMERCIAL PLATFORM METRICS",
                color = TextMutedDark,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Monthly MRR",
                    value = "₹4,82,000",
                    subtitle = "+24% vs last month",
                    icon = Icons.Default.CurrencyRupee,
                    accentColor = Color(0xFF10B981),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Compute API Cost",
                    value = "$4,120",
                    subtitle = "Veo / Kling / Flux",
                    icon = Icons.Default.Memory,
                    accentColor = Color(0xFFF59E0B),
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Total Users",
                    value = "12,450",
                    subtitle = "3,820 active today",
                    icon = Icons.Default.PeopleAlt,
                    accentColor = Color(0xFF3B82F6),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Failure Rate",
                    value = "0.2%",
                    subtitle = "99.8% completion rate",
                    icon = Icons.Default.CheckCircleOutline,
                    accentColor = Color(0xFF06B6D4),
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(18.dp))
        }

        // Generation Activity Totals
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "GENERATION ENGINE AGGREGATES",
                        color = TextMutedDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$totalVideos", color = Color(0xFFA855F7), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Videos", color = TextSecondaryDark, fontSize = 11.sp)
                        }
                        Divider(color = SaaSSurfaceBorder, modifier = Modifier.height(30.dp).width(1.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$totalImages", color = Color(0xFF10B981), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Images", color = TextSecondaryDark, fontSize = 11.sp)
                        }
                        Divider(color = SaaSSurfaceBorder, modifier = Modifier.height(30.dp).width(1.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$totalVoice", color = Color(0xFF38BDF8), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Text("Voiceovers", color = TextSecondaryDark, fontSize = 11.sp)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // AI Provider Architecture & Runtime Status
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(
                        listOf(Color(0xFF2563EB).copy(alpha = 0.4f), Color(0xFF7C3AED).copy(alpha = 0.4f))
                    )
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Dns, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AI PROVIDER ROUTING & STATUS",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }

                        val isMock = repository.aiRouter.isMockMode()
                        val currentMode = repository.aiRouter.getCurrentImageMode()

                        Surface(
                            color = if (isMock) Color(0xFF1E3A8A) else Color(0xFF065F46),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = if (isMock) "MOCK MODE (ZERO COST)" else "LIVE MODE: ${currentMode.displayName.uppercase()}",
                                color = if (isMock) Color(0xFF93C5FD) else Color(0xFFA7F3D0),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Real-time health check of multi-model provider abstraction services with Replicate API token verification.",
                        color = TextSecondaryDark,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    val providerStatusList = repository.aiRouter.buildProviderStatusList()
                    providerStatusList.forEach { info ->
                        Surface(
                            color = ObsidianBackground,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(info.category, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("•", color = TextMutedDark, fontSize = 11.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(info.modelName, color = Color(0xFF94A3B8), fontSize = 11.sp)
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(info.note, color = TextMutedDark, fontSize = 10.sp)
                                }

                                Surface(
                                    color = when (info.status) {
                                        ProviderStatus.MOCK -> Color(0xFF065F46)
                                        ProviderStatus.CONFIGURED -> Color(0xFF1E40AF)
                                        ProviderStatus.UNAVAILABLE -> Color(0xFF881337)
                                    },
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = info.status.displayName.uppercase(),
                                        color = when (info.status) {
                                            ProviderStatus.MOCK -> Color(0xFFA7F3D0)
                                            ProviderStatus.CONFIGURED -> Color(0xFFBFDBFE)
                                            ProviderStatus.UNAVAILABLE -> Color(0xFFFECDD3)
                                        },
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // User Management Table
        item {
            Text(
                text = "USER & TENANT MANAGEMENT",
                color = TextMutedDark,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        items(adminUsers) { user ->
            Surface(
                color = SaaSSurfaceCard,
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .testTag("admin_user_${user.id}")
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = user.name,
                                    color = TextPrimaryDark,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                if (user.isBlocked) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        color = Color(0xFF881337),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = "BLOCKED",
                                            color = Color(0xFFFECDD3),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = "${user.email} • Plan: ${user.plan}",
                                color = TextSecondaryDark,
                                fontSize = 11.sp
                            )
                        }

                        Text(
                            text = "${user.credits} ⚡",
                            color = Color(0xFFFBBF24),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                repository.adjustUserCredits(user.id, 500)
                                Toast.makeText(context, "Added 500 credits to ${user.name}", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("+500 Credits", fontSize = 10.sp, color = Color(0xFF60A5FA))
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        OutlinedButton(
                            onClick = {
                                repository.adjustUserCredits(user.id, -200)
                                Toast.makeText(context, "Deducted 200 credits from ${user.name}", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("-200 Credits", fontSize = 10.sp, color = TextMutedDark)
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        FilledTonalButton(
                            onClick = {
                                repository.toggleBlockUser(user.id)
                                val status = if (!user.isBlocked) "Blocked" else "Unblocked"
                                Toast.makeText(context, "$status ${user.name}", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (user.isBlocked) Color(0xFF064E3B) else Color(0xFF4C0519),
                                contentColor = if (user.isBlocked) Color(0xFF6EE7B7) else Color(0xFFFDA4AF)
                            ),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text(if (user.isBlocked) "Unblock" else "Block", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
