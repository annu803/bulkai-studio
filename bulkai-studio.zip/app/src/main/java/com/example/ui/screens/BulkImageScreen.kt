package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.BulkAiRepository
import com.example.data.providers.*
import com.example.model.*
import com.example.ui.components.ChipLabel
import com.example.ui.components.SelectableChip
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BulkImageScreen(
    repository: BulkAiRepository,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val jobs by repository.jobs.collectAsState()
    val imageJobs = remember(jobs) { jobs.filter { it.type == JobType.IMAGE } }
    val credits by repository.credits.collectAsState()
    val selectedTier by repository.selectedTier.collectAsState()
    val projects by repository.projects.collectAsState()

    // Prompt state
    var promptInputText by remember {
        mutableStateOf(
            "Prompt 1: A hyper-realistic aerial photography of ancient Indian stone temple at sunrise.\n\n" +
            "Prompt 2: Cinematic portrait of a majestic royal Bengal tiger in morning mist of Jim Corbett.\n\n" +
            "Prompt 3: Vibrant traditional Holi festival celebration in Vrindavan with swirling powder colors.\n\n" +
            "Prompt 4: Futuristic cyber-metropolis of Mumbai year 2099 with flying vehicles and neon skyline.\n\n" +
            "Prompt 5: Serene wooden houseboat cruising through emerald backwaters of Alleppey Kerala."
        )
    }

    var individualPrompts by remember {
        mutableStateOf(
            listOf(
                "A hyper-realistic aerial photography of ancient Indian stone temple at sunrise.",
                "Cinematic portrait of a majestic royal Bengal tiger in morning mist of Jim Corbett.",
                "Vibrant traditional Holi festival celebration in Vrindavan with swirling powder colors.",
                "Futuristic cyber-metropolis of Mumbai year 2099 with flying vehicles and neon skyline.",
                "Serene wooden houseboat cruising through emerald backwaters of Alleppey Kerala."
            )
        )
    }

    // Input mode: 0 for Raw Textarea, 1 for Itemized Prompt Cards
    var inputModeTab by remember { mutableStateOf(0) }

    // Project selection
    var selectedProjectId by remember { mutableStateOf(projects.firstOrNull()?.id) }
    var showProjectDropdown by remember { mutableStateOf(false) }

    // Settings state
    var selectedAspectRatio by remember { mutableStateOf("1:1") }
    var selectedQuality by remember { mutableStateOf("High") }
    var selectedStyle by remember { mutableStateOf("Cinematic") }
    var imagesPerPrompt by remember { mutableStateOf(1) }

    val aspectRatios = listOf("1:1", "16:9", "9:16", "4:5")
    val qualities = listOf("Standard", "High")
    val styles = listOf("Realistic", "Cinematic", "Documentary", "Historical", "3D", "Illustration")
    val counts = listOf(1, 2, 4)

    // Generation Mode: MOCK, REPLICATE_ECONOMY, REPLICATE_PREMIUM
    var selectedGenMode by remember { mutableStateOf(repository.aiRouter.getCurrentImageMode()) }

    // Cost calculations based on selected mode
    val costPerImage = AiProviderPricingConfig.getCreditCost(selectedGenMode, selectedQuality)
    val totalImagesCount = individualPrompts.size * imagesPerPrompt
    val totalCreditsNeeded = costPerImage * totalImagesCount

    // Queue metrics
    val waitingCount = imageJobs.count { it.status == JobStatus.WAITING }
    val processingCount = imageJobs.count { it.status == JobStatus.PROCESSING }
    val completedCount = imageJobs.count { it.status == JobStatus.COMPLETED }
    val failedCount = imageJobs.count { it.status == JobStatus.FAILED }
    val totalInQueue = imageJobs.size
    val batchProgressPercent = if (totalInQueue > 0) ((completedCount.toFloat() / totalInQueue) * 100).toInt() else 0

    // Modals
    var showImportModal by remember { mutableStateOf(false) }
    var importModalTab by remember { mutableStateOf(0) } // 0: CSV, 1: TXT
    var csvTextInput by remember { mutableStateOf(repository.getSampleCsvContent()) }
    var txtTextInput by remember { mutableStateOf(repository.getSampleTxtContent()) }
    var showDownloadZipModal by remember { mutableStateOf(false) }
    var showNewPromptDialog by remember { mutableStateOf(false) }
    var newPromptText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 48.dp)
    ) {
        // Screen Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Bulk Image Generator",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Parallel multi-prompt generative AI image synthesis",
                        color = TextSecondaryDark,
                        fontSize = 12.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalButton(
                        onClick = { showImportModal = true },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color(0xFF1E293B),
                            contentColor = Color(0xFF93C5FD)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("btn_import_files")
                    ) {
                        Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Import CSV/TXT", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Project Association Bar
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.FolderSpecial, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("Target Project", color = TextMutedDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            val currentProj = projects.find { it.id == selectedProjectId }
                            Text(
                                text = currentProj?.name ?: "Independent Batch (No Project)",
                                color = TextPrimaryDark,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Box {
                        TextButton(
                            onClick = { showProjectDropdown = true },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Change", color = Color(0xFF60A5FA), fontSize = 12.sp)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(16.dp))
                        }

                        DropdownMenu(
                            expanded = showProjectDropdown,
                            onDismissRequest = { showProjectDropdown = false },
                            modifier = Modifier.background(SaaSSurfaceCard)
                        ) {
                            projects.forEach { proj ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(proj.name, color = TextPrimaryDark, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                            Text("${proj.imageCount} images • ${proj.type}", color = TextMutedDark, fontSize = 10.sp)
                                        }
                                    },
                                    onClick = {
                                        selectedProjectId = proj.id
                                        showProjectDropdown = false
                                    }
                                )
                            }
                            HorizontalDivider(color = SaaSSurfaceBorder)
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("+ Create New Project", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                },
                                onClick = {
                                    val newProj = repository.createProject("Bulk Image Campaign ${SimpleDateFormat("MMM dd", Locale.getDefault()).format(Date())}", "Image Series")
                                    selectedProjectId = newProj.id
                                    showProjectDropdown = false
                                    Toast.makeText(context, "Created project '${newProj.name}'!", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Mode Selector: Textarea Raw Paste vs Itemized Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = SaaSSurfaceCard,
                    shape = RoundedCornerShape(8.dp),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Row(modifier = Modifier.padding(2.dp)) {
                        Surface(
                            color = if (inputModeTab == 0) Color(0xFF2563EB) else Color.Transparent,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .clickable {
                                    // When switching to raw mode, format individualPrompts into textarea
                                    promptInputText = individualPrompts.mapIndexed { idx, p -> "Prompt ${idx + 1}: $p" }.joinToString("\n\n")
                                    inputModeTab = 0
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Bulk Textarea",
                                color = if (inputModeTab == 0) Color.White else TextMutedDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            color = if (inputModeTab == 1) Color(0xFF2563EB) else Color.Transparent,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .clickable {
                                    // Parse raw textarea into individual prompts
                                    val parsed = repository.parseBulkPrompts(promptInputText)
                                    if (parsed.isNotEmpty()) {
                                        individualPrompts = parsed
                                    }
                                    inputModeTab = 1
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Prompt Cards (${individualPrompts.size})",
                                color = if (inputModeTab == 1) Color.White else TextMutedDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Quick actions toolbar
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(
                        onClick = {
                            val samples = repository.getSamplePrompts()
                            individualPrompts = samples
                            promptInputText = samples.mapIndexed { idx, p -> "Prompt ${idx + 1}: $p" }.joinToString("\n\n")
                            Toast.makeText(context, "Loaded ${samples.size} sample prompts!", Toast.LENGTH_SHORT).show()
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Samples", color = Color(0xFF60A5FA), fontSize = 11.sp)
                    }

                    TextButton(
                        onClick = {
                            individualPrompts = emptyList()
                            promptInputText = ""
                            Toast.makeText(context, "Cleared all prompts", Toast.LENGTH_SHORT).show()
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        Icon(Icons.Default.ClearAll, contentDescription = null, tint = RoseError, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear", color = RoseError, fontSize = 11.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Mode 0: Large Textarea
        if (inputModeTab == 0) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                    shape = RoundedCornerShape(12.dp),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PASTE MULTIPLE PROMPTS",
                                color = TextMutedDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            val detectedCount = repository.parseBulkPrompts(promptInputText).size
                            Surface(
                                color = Color(0xFF1E293B),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "$detectedCount Detected",
                                    color = Color(0xFF60A5FA),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = promptInputText,
                            onValueChange = {
                                promptInputText = it
                                individualPrompts = repository.parseBulkPrompts(it)
                            },
                            placeholder = {
                                Text(
                                    text = "Paste multiple prompts separated by new lines or 'Prompt 1:', 'Prompt 2:'...\n\nSupports 1 to 100+ prompts.",
                                    color = TextMutedDark,
                                    fontSize = 12.sp
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(170.dp)
                                .testTag("textarea_bulk_prompts"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimaryDark,
                                unfocusedTextColor = TextPrimaryDark,
                                focusedContainerColor = ObsidianBackground,
                                unfocusedContainerColor = ObsidianBackground,
                                focusedBorderColor = Color(0xFF3B82F6),
                                unfocusedBorderColor = SaaSSurfaceBorder
                            ),
                            shape = RoundedCornerShape(8.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Detects: 'Prompt X:', numbered lists, or plain lines",
                                color = TextMutedDark,
                                fontSize = 11.sp
                            )

                            Button(
                                onClick = {
                                    val parsed = repository.parseBulkPrompts(promptInputText)
                                    if (parsed.isNotEmpty()) {
                                        individualPrompts = parsed
                                        inputModeTab = 1
                                        Toast.makeText(context, "Parsed ${parsed.size} individual prompt cards!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "No prompts detected. Enter text first.", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("View as Cards", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }
        }

        // Mode 1: Itemized Cards List
        if (inputModeTab == 1) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ACTIVE PROMPTS (${individualPrompts.size})",
                        color = TextMutedDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Button(
                        onClick = {
                            newPromptText = ""
                            showNewPromptDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(30.dp).testTag("btn_add_prompt")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Prompt", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
            }

            if (individualPrompts.isEmpty()) {
                item {
                    Surface(
                        color = SaaSSurfaceCard,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(20.dp)
                        ) {
                            Icon(Icons.Default.EditNote, contentDescription = null, tint = TextMutedDark, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("No prompts loaded", color = TextSecondaryDark, fontSize = 13.sp)
                            Text("Click '+ Add Prompt' or load samples above", color = TextMutedDark, fontSize = 11.sp)
                        }
                    }
                }
            } else {
                itemsIndexed(individualPrompts) { index, promptText ->
                    Surface(
                        color = SaaSSurfaceCard,
                        shape = RoundedCornerShape(8.dp),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "#${index + 1}",
                                color = Color(0xFF60A5FA),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(30.dp)
                            )
                            Text(
                                text = promptText,
                                color = TextPrimaryDark,
                                fontSize = 12.sp,
                                modifier = Modifier.weight(1f),
                                lineHeight = 16.sp
                            )
                            // Action: Duplicate
                            IconButton(
                                onClick = {
                                    val mutable = individualPrompts.toMutableList()
                                    mutable.add(index + 1, promptText)
                                    individualPrompts = mutable
                                    promptInputText = mutable.mapIndexed { i, p -> "Prompt ${i + 1}: $p" }.joinToString("\n\n")
                                    Toast.makeText(context, "Duplicated prompt #${index + 1}", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", tint = Color(0xFF93C5FD), modifier = Modifier.size(14.dp))
                            }
                            // Action: Delete
                            IconButton(
                                onClick = {
                                    val mutable = individualPrompts.toMutableList()
                                    mutable.removeAt(index)
                                    individualPrompts = mutable
                                    promptInputText = mutable.mapIndexed { i, p -> "Prompt ${i + 1}: $p" }.joinToString("\n\n")
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Delete", tint = TextMutedDark, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(14.dp)) }
        }

        // IMAGE SETTINGS PANEL
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "IMAGE SETTINGS & GENERATION MODE",
                            color = TextMutedDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Surface(
                            color = if (selectedGenMode == ImageGenerationMode.MOCK) Color(0xFF1E293B) else Color(0xFF064E3B),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = if (selectedGenMode == ImageGenerationMode.MOCK) "Zero-Cost Simulation" else "Commercial API",
                                color = if (selectedGenMode == ImageGenerationMode.MOCK) Color(0xFF94A3B8) else Color(0xFF6EE7B7),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    // Generation Engine Mode Selection
                    Text("Generation Engine (Provider Mode)", color = TextSecondaryDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        ImageGenerationMode.values().forEach { mode ->
                            val isSelected = selectedGenMode == mode
                            val costBadge = when (mode) {
                                ImageGenerationMode.MOCK -> "0$ • Free"
                                ImageGenerationMode.REPLICATE_ECONOMY -> "$0.01 / img • 3⚡"
                                ImageGenerationMode.REPLICATE_PREMIUM -> "$0.04 / img • 8⚡"
                            }
                            val modelSubtitle = when (mode) {
                                ImageGenerationMode.MOCK -> "Local simulated diffusion synthesis"
                                ImageGenerationMode.REPLICATE_ECONOMY -> "Replicate: minimax/image-01"
                                ImageGenerationMode.REPLICATE_PREMIUM -> "Replicate: google/imagen-4"
                            }

                            Surface(
                                onClick = {
                                    selectedGenMode = mode
                                    repository.aiRouter.setImageGenerationMode(mode)
                                },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) Color(0xFF1E3A8A) else Color(0xFF0F172A),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) Color(0xFF3B82F6) else Color(0xFF334155)
                                ),
                                modifier = Modifier.fillMaxWidth().testTag("mode_${mode.name.lowercase()}")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = mode.displayName,
                                                color = if (isSelected) Color.White else TextPrimaryDark,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            if (mode != ImageGenerationMode.MOCK) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Surface(
                                                    color = Color(0xFF0284C7).copy(alpha = 0.3f),
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        text = "REAL",
                                                        color = Color(0xFF38BDF8),
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = modelSubtitle,
                                            color = TextMutedDark,
                                            fontSize = 10.sp
                                        )
                                    }

                                    Surface(
                                        color = if (isSelected) Color(0xFF2563EB).copy(alpha = 0.4f) else Color(0xFF1E293B),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = costBadge,
                                            color = if (isSelected) Color(0xFF93C5FD) else TextSecondaryDark,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Aspect Ratio
                    Text("Aspect Ratio", color = TextSecondaryDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        aspectRatios.forEach { ratio ->
                            SelectableChip(
                                label = ratio,
                                isSelected = selectedAspectRatio == ratio,
                                onClick = { selectedAspectRatio = ratio },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quality & Images Per Prompt Row
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Quality", color = TextSecondaryDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                qualities.forEach { q ->
                                    SelectableChip(
                                        label = if (q == "Standard") "Standard (3⚡)" else "High 8K (5⚡)",
                                        isSelected = selectedQuality == q,
                                        onClick = { selectedQuality = q },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Images per Prompt", color = TextSecondaryDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                counts.forEach { count ->
                                    SelectableChip(
                                        label = "$count",
                                        isSelected = imagesPerPrompt == count,
                                        onClick = { imagesPerPrompt = count },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Visual Style
                    Text("Visual Style", color = TextSecondaryDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(styles) { style ->
                            SelectableChip(
                                label = style,
                                isSelected = selectedStyle == style,
                                onClick = { selectedStyle = style }
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // GENERATE ALL BUTTON
        item {
            Button(
                onClick = {
                    if (individualPrompts.isEmpty()) {
                        Toast.makeText(context, "Add at least one prompt", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (credits < totalCreditsNeeded) {
                        Toast.makeText(context, "Insufficient credits (Need $totalCreditsNeeded ⚡)", Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    repository.addBulkImageJobs(
                        prompts = individualPrompts,
                        aspectRatio = selectedAspectRatio,
                        quality = selectedQuality,
                        style = selectedStyle,
                        tier = selectedTier,
                        projectId = selectedProjectId,
                        imagesPerPrompt = imagesPerPrompt,
                        mode = selectedGenMode
                    )
                    val modeLabel = if (selectedGenMode == ImageGenerationMode.MOCK) "Mock synthesis queue" else "Replicate (${selectedGenMode.displayName})"
                    Toast.makeText(
                        context,
                        "Dispatched $totalImagesCount image tasks to $modeLabel!",
                        Toast.LENGTH_SHORT
                    ).show()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedGenMode == ImageGenerationMode.MOCK) Color(0xFF059669) else Color(0xFF2563EB)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("btn_generate_all_images")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "GENERATE ALL ($totalImagesCount IMAGES)",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "• $totalCreditsNeeded ⚡",
                        color = Color(0xFFA7F3D0),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // BATCH PROGRESS & QUEUE CONTROLS
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = "BULK IMAGE QUEUE",
                                color = TextMutedDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = if (totalInQueue > 0) "Batch Progress: $completedCount of $totalInQueue Completed ($batchProgressPercent%)" else "Queue is empty",
                                color = if (completedCount == totalInQueue && totalInQueue > 0) Color(0xFF10B981) else Color(0xFF93C5FD),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        if (completedCount > 0) {
                            Button(
                                onClick = { showDownloadZipModal = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("btn_download_all_images")
                            ) {
                                Icon(Icons.Default.Archive, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("DOWNLOAD ALL (ZIP)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (totalInQueue > 0) {
                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { if (totalInQueue > 0) completedCount.toFloat() / totalInQueue else 0f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = Color(0xFF10B981),
                            trackColor = Color(0xFF1E293B)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Status badges summary row
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            QueueStatusPill(label = "Waiting", count = waitingCount, color = Color(0xFF6B7280))
                            QueueStatusPill(label = "Processing", count = processingCount, color = Color(0xFF3B82F6))
                            QueueStatusPill(label = "Completed", count = completedCount, color = Color(0xFF10B981))
                            if (failedCount > 0) {
                                QueueStatusPill(label = "Failed", count = failedCount, color = RoseError)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Queue action buttons
                        Row(
                            horizontalArrangement = Arrangement.End,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (failedCount > 0) {
                                TextButton(
                                    onClick = {
                                        repository.retryAllFailedJobs(JobType.IMAGE)
                                        Toast.makeText(context, "Retrying failed image jobs...", Toast.LENGTH_SHORT).show()
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Retry Failed", color = Color(0xFF60A5FA), fontSize = 11.sp)
                                }
                            }

                            if (completedCount > 0) {
                                TextButton(
                                    onClick = {
                                        repository.clearCompletedJobs(JobType.IMAGE)
                                        Toast.makeText(context, "Cleared completed jobs from queue", Toast.LENGTH_SHORT).show()
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Text("Clear Completed", color = TextSecondaryDark, fontSize = 11.sp)
                                }
                            }

                            TextButton(
                                onClick = {
                                    repository.clearAllImageJobs()
                                    Toast.makeText(context, "Cleared image queue", Toast.LENGTH_SHORT).show()
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp)
                            ) {
                                Text("Clear Queue", color = RoseError, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // QUEUE ITEMS
        if (imageJobs.isEmpty()) {
            item {
                Surface(
                    color = SaaSSurfaceCard,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(Icons.Default.ImageNotSupported, contentDescription = null, tint = TextMutedDark, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No image jobs in queue", color = TextSecondaryDark, fontSize = 13.sp)
                        Text("Configure prompts and tap GENERATE ALL to launch jobs", color = TextMutedDark, fontSize = 11.sp)
                    }
                }
            }
        } else {
            items(imageJobs, key = { it.id }) { job ->
                ImageJobCard(
                    job = job,
                    onDownload = {
                        Toast.makeText(
                            context,
                            "Downloaded /sdcard/Download/BulkAI_${job.jobNumber}_${job.aspectRatio.replace(":", "x")}.png",
                            Toast.LENGTH_LONG
                        ).show()
                    },
                    onRegenerate = {
                        repository.retryJob(job.id)
                        Toast.makeText(context, "Re-queued ${job.jobNumber}", Toast.LENGTH_SHORT).show()
                    },
                    onDelete = {
                        repository.deleteJob(job.id)
                    }
                )
            }
        }
    }

    // Modal: Add Single Prompt Dialog
    if (showNewPromptDialog) {
        AlertDialog(
            onDismissRequest = { showNewPromptDialog = false },
            title = { Text("Add New Prompt", color = TextPrimaryDark, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPromptText,
                    onValueChange = { newPromptText = it },
                    placeholder = { Text("Enter prompt description...", color = TextMutedDark) },
                    modifier = Modifier.fillMaxWidth().height(120.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark,
                        focusedContainerColor = SaaSSurfaceCard,
                        unfocusedContainerColor = SaaSSurfaceCard
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPromptText.isNotBlank()) {
                            val clean = repository.cleanPromptText(newPromptText)
                            individualPrompts = individualPrompts + clean
                            promptInputText = individualPrompts.mapIndexed { idx, p -> "Prompt ${idx + 1}: $p" }.joinToString("\n\n")
                            showNewPromptDialog = false
                            Toast.makeText(context, "Added prompt #${individualPrompts.size}", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                ) {
                    Text("Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewPromptDialog = false }) {
                    Text("Cancel", color = TextSecondaryDark)
                }
            },
            containerColor = SaaSSurface
        )
    }

    // Modal: CSV & TXT File Import
    if (showImportModal) {
        AlertDialog(
            onDismissRequest = { showImportModal = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.UploadFile, contentDescription = null, tint = Color(0xFF60A5FA))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Import Prompts File", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                }
            },
            text = {
                Column {
                    // Tab Selector: CSV vs TXT
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = if (importModalTab == 0) Color(0xFF2563EB) else Color(0xFF1E293B),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { importModalTab = 0 }
                                .padding(vertical = 6.dp)
                        ) {
                            Text(
                                text = "CSV File",
                                color = if (importModalTab == 0) Color.White else TextSecondaryDark,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 4.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }

                        Surface(
                            color = if (importModalTab == 1) Color(0xFF2563EB) else Color(0xFF1E293B),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { importModalTab = 1 }
                                .padding(vertical = 6.dp)
                        ) {
                            Text(
                                text = "TXT File",
                                color = if (importModalTab == 1) Color.White else TextSecondaryDark,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 4.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (importModalTab == 0) {
                        Text(
                            text = "CSV requires a column named 'prompt'. Each row becomes one image generation job.",
                            color = TextSecondaryDark,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilledTonalButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(repository.getSampleCsvContent()))
                                    Toast.makeText(context, "Sample CSV copied to clipboard & downloaded to /sdcard/Download/bulkai_sample.csv", Toast.LENGTH_LONG).show()
                                },
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Download Sample CSV", fontSize = 10.sp)
                            }

                            FilledTonalButton(
                                onClick = { csvTextInput = repository.getSampleCsvContent() },
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text("Load Sample", fontSize = 10.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = csvTextInput,
                            onValueChange = { csvTextInput = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimaryDark,
                                unfocusedTextColor = TextPrimaryDark,
                                focusedContainerColor = SaaSSurfaceCard,
                                unfocusedContainerColor = SaaSSurfaceCard
                            )
                        )
                    } else {
                        Text(
                            text = "Plain TXT format: Each non-empty line becomes one image generation job.",
                            color = TextSecondaryDark,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        FilledTonalButton(
                            onClick = { txtTextInput = repository.getSampleTxtContent() },
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Load Sample TXT", fontSize = 10.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = txtTextInput,
                            onValueChange = { txtTextInput = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimaryDark,
                                unfocusedTextColor = TextPrimaryDark,
                                focusedContainerColor = SaaSSurfaceCard,
                                unfocusedContainerColor = SaaSSurfaceCard
                            )
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsed = if (importModalTab == 0) {
                            repository.parseCsvPrompts(csvTextInput)
                        } else {
                            repository.parseTxtPrompts(txtTextInput)
                        }

                        if (parsed.isNotEmpty()) {
                            individualPrompts = individualPrompts + parsed
                            promptInputText = individualPrompts.mapIndexed { idx, p -> "Prompt ${idx + 1}: $p" }.joinToString("\n\n")
                            inputModeTab = 1
                            Toast.makeText(context, "Successfully imported ${parsed.size} prompts!", Toast.LENGTH_SHORT).show()
                            showImportModal = false
                        } else {
                            Toast.makeText(context, "No prompts could be parsed. Check format.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                ) {
                    Text("Import Prompts")
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportModal = false }) {
                    Text("Cancel", color = TextSecondaryDark)
                }
            },
            containerColor = SaaSSurface
        )
    }

    // Modal: Download All ZIP Archive Dialog
    if (showDownloadZipModal) {
        val dateStr = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
        val archiveName = "BulkAI_Images_Batch_$dateStr.zip"
        val estSizeMb = "%.1f".format(completedCount * 4.2)

        AlertDialog(
            onDismissRequest = { showDownloadZipModal = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FolderZip, contentDescription = null, tint = Color(0xFF60A5FA))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Download Batch Archive", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimaryDark)
                }
            },
            text = {
                Column {
                    Text("Package and download all completed images in a single ZIP archive:", color = TextSecondaryDark, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = SaaSSurfaceCard,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("Filename: $archiveName", color = Color(0xFF93C5FD), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Total Images: $completedCount PNG files", color = TextPrimaryDark, fontSize = 11.sp)
                            Text("Estimated Size: ~$estSizeMb MB", color = TextSecondaryDark, fontSize = 11.sp)
                            Text("Includes: High-resolution PNGs + manifest.json", color = Color(0xFF10B981), fontSize = 11.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        Toast.makeText(
                            context,
                            "Saved $archiveName to /sdcard/Download/ ($completedCount images)",
                            Toast.LENGTH_LONG
                        ).show()
                        showDownloadZipModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A))
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Confirm Download")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDownloadZipModal = false }) {
                    Text("Close", color = TextSecondaryDark)
                }
            },
            containerColor = SaaSSurface
        )
    }
}

@Composable
fun QueueStatusPill(label: String, count: Int, color: Color) {
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(4.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "$label: $count",
                color = color,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ImageJobCard(
    job: GenerationJob,
    onDownload: () -> Unit,
    onRegenerate: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(
                listOf(SaaSSurfaceBorder, Color(job.previewAccentColor).copy(alpha = 0.35f))
            )
        ),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .testTag("job_card_${job.jobNumber}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Job ID, Type, Status Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = job.jobNumber,
                        color = Color(0xFF60A5FA),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = Color(job.previewAccentColor).copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "IMAGE",
                            color = Color(job.previewAccentColor),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                StatusBadge(status = job.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Prompt text
            Text(
                text = job.prompt,
                color = TextPrimaryDark,
                fontSize = 13.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Metadata chips
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ChipLabel(text = job.model, icon = Icons.Default.SmartToy)
                ChipLabel(text = job.aspectRatio, icon = Icons.Default.AspectRatio)
                ChipLabel(text = job.quality, icon = Icons.Default.HighQuality)
                ChipLabel(text = job.style, icon = Icons.Default.Palette)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Visual State Representation
            when (job.status) {
                JobStatus.WAITING -> {
                    Surface(
                        color = ObsidianBackground,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.HourglassEmpty, contentDescription = "Waiting", tint = TextMutedDark, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Waiting for worker thread...", color = TextMutedDark, fontSize = 12.sp)
                        }
                    }
                }

                JobStatus.SUBMITTING -> {
                    Surface(
                        color = ObsidianBackground,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = "Submitting", tint = Color(0xFFA5B4FC), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Submitting prediction to Replicate...", color = Color(0xFFA5B4FC), fontSize = 12.sp)
                        }
                    }
                }

                JobStatus.PROCESSING -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(ObsidianBackground)
                            .padding(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Synthesizing latents with ${job.model}...",
                                color = Color(0xFF93C5FD),
                                fontSize = 11.sp
                            )
                            Text(
                                text = "${job.progress}%",
                                color = Color(0xFF60A5FA),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { job.progress / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = Color(0xFF3B82F6),
                            trackColor = Color(0xFF1E293B)
                        )
                    }
                }

                JobStatus.COMPLETED -> {
                    // Realistic placeholder preview card with image support
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(ObsidianBackground)
                            .border(1.dp, Color(job.previewAccentColor).copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    ) {
                        // Attempt to load Coil AsyncImage; fallback gradient underneath
                        if (job.imageUrl != null) {
                            AsyncImage(
                                model = job.imageUrl,
                                contentDescription = job.prompt,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // Gradient overlay for contrast
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Transparent,
                                            Color.Black.copy(alpha = 0.75f)
                                        )
                                    )
                                )
                        )

                        // Resolution Badge top right
                        Surface(
                            color = Color.Black.copy(alpha = 0.7f),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = if (job.quality == "High") "4K UHD" else "Standard HD",
                                color = Color(0xFF10B981),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        // Aspect ratio badge top left
                        Surface(
                            color = Color.Black.copy(alpha = 0.7f),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = job.aspectRatio,
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        // Bottom label
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${job.style} • ${job.model}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                JobStatus.FAILED -> {
                    Surface(
                        color = Color(0xFF4C0519),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().padding(4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = RoseError, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = job.error ?: "Generation timed out. Tap retry to re-queue.",
                                    color = Color(0xFFFDA4AF),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                JobStatus.CANCELLED -> {
                    Surface(
                        color = Color(0xFF1F2937),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().padding(4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Cancel, contentDescription = null, tint = Color(0xFF9CA3AF), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Generation was cancelled. Reserved credits refunded.",
                                    color = Color(0xFF9CA3AF),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = Color(0xFF1E293B),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "${job.providerName} • ${job.requestId.take(11)}...",
                        color = Color(0xFF94A3B8),
                        fontSize = 9.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (job.status == JobStatus.COMPLETED) {
                        FilledTonalButton(
                            onClick = onDownload,
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Color(0xFF1E3A8A),
                                contentColor = Color(0xFF93C5FD)
                            ),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(34.dp)
                                .testTag("download_job_${job.jobNumber}")
                        ) {
                            Icon(Icons.Default.Download, contentDescription = "Download", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Download", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    if (job.status == JobStatus.FAILED) {
                        Button(
                            onClick = onRegenerate,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier
                                .height(34.dp)
                                .testTag("retry_job_${job.jobNumber}")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Retry", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Retry", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    } else if (job.status == JobStatus.COMPLETED) {
                        IconButton(
                            onClick = onRegenerate,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("regenerate_job_${job.jobNumber}")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Regenerate", tint = TextSecondaryDark, modifier = Modifier.size(16.dp))
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(34.dp)
                            .testTag("delete_job_${job.jobNumber}")
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = TextMutedDark, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
