package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BulkAiRepository
import com.example.model.*
import com.example.ui.components.JobQueueItem
import com.example.ui.components.SelectableChip
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BulkVideoScreen(
    repository: BulkAiRepository,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val jobs by repository.jobs.collectAsState()
    val videoJobs = remember(jobs) { jobs.filter { it.type == JobType.VIDEO } }
    val credits by repository.credits.collectAsState()
    val selectedTier by repository.selectedTier.collectAsState()

    // Prompt state
    var promptInputText by remember {
        mutableStateOf(
            "Prompt 1:\nA cinematic aerial view of Kedarnath temple surrounded by snowy Himalayan mountains.\n\n" +
            "Prompt 2:\nA realistic documentary scene showing heavy rainfall in the Himalayas.\n\n" +
            "Prompt 3:\nA massive river flood moving through a mountain valley."
        )
    }

    var individualPrompts by remember {
        mutableStateOf(
            listOf(
                "A cinematic aerial view of Kedarnath temple surrounded by snowy Himalayan mountains.",
                "A realistic documentary scene showing heavy rainfall in the Himalayas.",
                "A massive river flood moving through a mountain valley."
            )
        )
    }

    var isRawMode by remember { mutableStateOf(false) }

    // Settings state
    var selectedAspectRatio by remember { mutableStateOf("16:9") }
    var selectedDuration by remember { mutableStateOf("8 seconds") }
    var selectedQuality by remember { mutableStateOf("High") }
    var selectedStyle by remember { mutableStateOf("Cinematic") }

    val aspectRatios = listOf("9:16", "16:9", "1:1")
    val durations = listOf("5 seconds", "8 seconds", "10 seconds")
    val qualities = listOf("Standard", "High")
    val styles = listOf("Realistic", "Cinematic", "Documentary", "Historical", "3D", "Animation")

    val creditCostPerVideo = when (selectedDuration) {
        "5 seconds" -> 10 * selectedTier.creditMultiplier
        "8 seconds" -> 15 * selectedTier.creditMultiplier
        else -> 20 * selectedTier.creditMultiplier
    }
    val totalCreditsNeeded = creditCostPerVideo * individualPrompts.size

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp)
    ) {
        // Screen Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "Bulk Video Generator",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Batch render multi-prompt AI videos simultaneously",
                        color = TextSecondaryDark,
                        fontSize = 12.sp
                    )
                }

                Surface(
                    color = SaaSSurfaceCard,
                    shape = RoundedCornerShape(8.dp),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${individualPrompts.size} Prompts",
                            color = Color(0xFF60A5FA),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Mode Selector: Bulk Paste vs Itemized Card List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(SaaSSurfaceCard)
                        .padding(2.dp)
                ) {
                    Surface(
                        color = if (!isRawMode) Color(0xFF1E3A8A) else Color.Transparent,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.clickable { isRawMode = false }
                    ) {
                        Text(
                            text = "List View (${individualPrompts.size})",
                            color = if (!isRawMode) Color.White else TextMutedDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                    Surface(
                        color = if (isRawMode) Color(0xFF1E3A8A) else Color.Transparent,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.clickable { isRawMode = true }
                    ) {
                        Text(
                            text = "Raw Paste Area",
                            color = if (isRawMode) Color.White else TextMutedDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }

                // Quick presets
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(
                        onClick = {
                            val detected = repository.parseBulkPrompts(promptInputText)
                            if (detected.isNotEmpty()) {
                                individualPrompts = detected
                                Toast.makeText(context, "Detected ${detected.size} prompts!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF60A5FA))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Detect Numbered", fontSize = 11.sp, color = Color(0xFF60A5FA))
                    }

                    TextButton(
                        onClick = {
                            individualPrompts = emptyList()
                            promptInputText = ""
                        },
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text("Clear All", fontSize = 11.sp, color = RoseError)
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Prompt Input Display
        if (isRawMode) {
            item {
                OutlinedTextField(
                    value = promptInputText,
                    onValueChange = {
                        promptInputText = it
                        individualPrompts = repository.parseBulkPrompts(it)
                    },
                    label = { Text("Paste bulk prompts (e.g. 'Prompt 1: ... Prompt 2: ...')", fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF3B82F6),
                        unfocusedBorderColor = SaaSSurfaceBorder,
                        focusedContainerColor = SaaSSurfaceCard,
                        unfocusedContainerColor = SaaSSurfaceCard,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .testTag("bulk_video_raw_input")
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        } else {
            itemsIndexed(individualPrompts) { index, promptText ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                    shape = RoundedCornerShape(10.dp),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(listOf(SaaSSurfaceBorder, Color(0xFF3B82F6).copy(alpha = 0.2f)))
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Prompt ${index + 1}",
                                color = Color(0xFF60A5FA),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row {
                                IconButton(
                                    onClick = {
                                        // Duplicate
                                        individualPrompts = individualPrompts.toMutableList().also {
                                            it.add(index + 1, promptText)
                                        }
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", tint = TextMutedDark, modifier = Modifier.size(14.dp))
                                }
                                IconButton(
                                    onClick = {
                                        // Delete
                                        individualPrompts = individualPrompts.filterIndexed { i, _ -> i != index }
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Delete", tint = RoseError, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                        Text(
                            text = promptText,
                            color = TextPrimaryDark,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    OutlinedButton(
                        onClick = {
                            individualPrompts = individualPrompts + "A dramatic cinematic landscape with golden atmospheric volumetric lighting."
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF60A5FA)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("+ Add Prompt", fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    OutlinedButton(
                        onClick = {
                            individualPrompts = listOf(
                                "A cinematic aerial view of Kedarnath temple surrounded by snowy Himalayan mountains.",
                                "A realistic documentary scene showing heavy rainfall in the Himalayas.",
                                "A massive river flood moving through a mountain valley.",
                                "Historic Varanasi riverfront ghats illuminated by thousands of evening brass lamps.",
                                "Ancient Amber Fort in Jaipur with majestic elephant procession at dawn."
                            )
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondaryDark),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Load 5 Samples", fontSize = 12.sp)
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }
        }

        // Video Settings Controls Panel
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "VIDEO GENERATION SETTINGS",
                            color = TextMutedDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "${selectedTier.displayName}",
                            color = Color(0xFF93C5FD),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Aspect Ratio
                    Text("Aspect Ratio", color = TextSecondaryDark, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        aspectRatios.forEach { ratio ->
                            SelectableChip(
                                label = ratio,
                                isSelected = selectedAspectRatio == ratio,
                                onClick = { selectedAspectRatio = ratio },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Duration
                    Text("Duration", color = TextSecondaryDark, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        durations.forEach { duration ->
                            SelectableChip(
                                label = duration,
                                isSelected = selectedDuration == duration,
                                onClick = { selectedDuration = duration },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quality & Style
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Quality", color = TextSecondaryDark, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                qualities.forEach { q ->
                                    SelectableChip(
                                        label = q,
                                        isSelected = selectedQuality == q,
                                        onClick = { selectedQuality = q },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Style Row
                    Text("Visual Style", color = TextSecondaryDark, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(styles) { style ->
                            SelectableChip(
                                label = style,
                                isSelected = selectedStyle == style,
                                onClick = { selectedStyle = style }
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // GENERATE ALL Big Action Button
        item {
            Button(
                onClick = {
                    if (individualPrompts.isEmpty()) {
                        Toast.makeText(context, "Please enter at least one prompt", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (credits < totalCreditsNeeded) {
                        Toast.makeText(context, "Insufficient credits ($credits available, $totalCreditsNeeded required)", Toast.LENGTH_LONG).show()
                    }
                    repository.addBulkVideoJobs(
                        prompts = individualPrompts,
                        duration = selectedDuration,
                        aspectRatio = selectedAspectRatio,
                        quality = selectedQuality,
                        style = selectedStyle,
                        tier = selectedTier
                    )
                    Toast.makeText(context, "Queued ${individualPrompts.size} video jobs!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF2563EB)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("btn_generate_all_videos")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(0xFFFBBF24))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "GENERATE ALL (${individualPrompts.size} VIDEOS)",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "• $totalCreditsNeeded ⚡",
                        color = Color(0xFF93C5FD),
                        fontSize = 13.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Bulk Video Job Queue
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "BULK VIDEO JOB QUEUE",
                        color = TextMutedDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${videoJobs.size} Video Tasks",
                        color = Color(0xFF60A5FA),
                        fontSize = 12.sp
                    )
                }
                if (videoJobs.isNotEmpty()) {
                    TextButton(
                        onClick = { repository.clearAllJobs() },
                        contentPadding = PaddingValues(horizontal = 6.dp)
                    ) {
                        Text("Clear Queue", color = TextMutedDark, fontSize = 11.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        if (videoJobs.isEmpty()) {
            item {
                Surface(
                    color = SaaSSurfaceCard,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(Icons.Default.VideocamOff, contentDescription = null, tint = TextMutedDark, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No video generation jobs yet", color = TextSecondaryDark, fontSize = 13.sp)
                        Text("Click GENERATE ALL to dispatch video rendering tasks", color = TextMutedDark, fontSize = 11.sp)
                    }
                }
            }
        } else {
            items(videoJobs) { job ->
                JobQueueItem(
                    job = job,
                    onRegenerate = { repository.regenerateJob(job.id) },
                    onDelete = { repository.deleteJob(job.id) },
                    onDownload = {
                        Toast.makeText(context, "Downloading simulated 4K MP4 for ${job.jobNumber}", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}
