package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BulkAiRepository
import com.example.model.CreditTransaction
import com.example.ui.theme.*

@Composable
fun CreditsScreen(
    repository: BulkAiRepository,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val credits by repository.credits.collectAsState()
    val transactions by repository.transactions.collectAsState()

    var showTopUpDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp)
    ) {
        // Header
        item {
            Text(
                text = "Credits & Usage",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Track API compute quotas, batch deductions and billing balance",
                color = TextSecondaryDark,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Big Credits Hero Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFFF59E0B).copy(alpha = 0.4f), Color(0xFF3B82F6).copy(alpha = 0.4f))
                    )
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("credits_balance_card")
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "AVAILABLE COMPUTE CREDITS",
                            color = TextMutedDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Surface(
                            color = Color(0xFF78350F),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "Auto-refills Monthly",
                                color = Color(0xFFFDE68A),
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "$credits",
                            color = Color.White,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Credits Remaining",
                            color = Color(0xFFFBBF24),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Usage Progress breakdown bar
                    Text("Usage Distribution (This Cycle)", color = TextSecondaryDark, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                    ) {
                        Box(modifier = Modifier.weight(0.68f).fillMaxHeight().background(Color(0xFF3B82F6)))
                        Box(modifier = Modifier.weight(0.22f).fillMaxHeight().background(Color(0xFF10B981)))
                        Box(modifier = Modifier.weight(0.10f).fillMaxHeight().background(Color(0xFF8B5CF6)))
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LegendItem("Video (68%)", Color(0xFF3B82F6))
                        LegendItem("Image (22%)", Color(0xFF10B981))
                        LegendItem("Voice (10%)", Color(0xFF8B5CF6))
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = { showTopUpDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("btn_top_up_credits")
                    ) {
                        Icon(Icons.Default.AddCircleOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Add / Top-Up Credits", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Pricing Packages Quick Grid
        item {
            Text(
                text = "TOP-UP CREDIT PACKAGES",
                color = TextMutedDark,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PackageCard(
                    credits = "+500",
                    price = "₹199",
                    subtext = "Quick Batch",
                    modifier = Modifier.weight(1f),
                    onBuy = {
                        repository.topUpCredits(500)
                        Toast.makeText(context, "Added 500 Credits!", Toast.LENGTH_SHORT).show()
                    }
                )
                PackageCard(
                    credits = "+1,500",
                    price = "₹499",
                    subtext = "Most Popular",
                    isHighlight = true,
                    modifier = Modifier.weight(1f),
                    onBuy = {
                        repository.topUpCredits(1500)
                        Toast.makeText(context, "Added 1,500 Credits!", Toast.LENGTH_SHORT).show()
                    }
                )
                PackageCard(
                    credits = "+5,000",
                    price = "₹1,299",
                    subtext = "Best Value",
                    modifier = Modifier.weight(1f),
                    onBuy = {
                        repository.topUpCredits(5000)
                        Toast.makeText(context, "Added 5,000 Credits!", Toast.LENGTH_SHORT).show()
                    }
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Usage History Table
        item {
            Text(
                text = "CREDIT TRANSACTION LOGS",
                color = TextMutedDark,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        items(transactions) { tx ->
            Surface(
                color = SaaSSurfaceCard,
                shape = RoundedCornerShape(8.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(
                                    if (tx.amount > 0) Color(0xFF064E3B) else Color(0xFF1E293B)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (tx.amount > 0) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                contentDescription = null,
                                tint = if (tx.amount > 0) Color(0xFF6EE7B7) else Color(0xFF93C5FD),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = tx.description, color = TextPrimaryDark, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Text(text = "${tx.type} • ${tx.timestamp}", color = TextMutedDark, fontSize = 10.sp)
                        }
                    }

                    Text(
                        text = if (tx.amount > 0) "+${tx.amount} ⚡" else "${tx.amount} ⚡",
                        color = if (tx.amount > 0) Color(0xFF10B981) else Color(0xFFF87171),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    if (showTopUpDialog) {
        AlertDialog(
            onDismissRequest = { showTopUpDialog = false },
            title = { Text("Top-Up Credits", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Simulate adding 1,000 instant credits to your account for testing prototype workloads:",
                    color = TextSecondaryDark,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        repository.topUpCredits(1000)
                        showTopUpDialog = false
                        Toast.makeText(context, "Added 1,000 Credits to account!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                ) {
                    Text("+1,000 Credits")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTopUpDialog = false }) {
                    Text("Cancel", color = TextSecondaryDark)
                }
            },
            containerColor = SaaSSurface
        )
    }
}

@Composable
fun PackageCard(
    credits: String,
    price: String,
    subtext: String,
    isHighlight: Boolean = false,
    modifier: Modifier = Modifier,
    onBuy: () -> Unit
) {
    Surface(
        color = if (isHighlight) Color(0xFF1E293B) else SaaSSurfaceCard,
        shape = RoundedCornerShape(10.dp),
        border = if (isHighlight) CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(listOf(Color(0xFF3B82F6), Color(0xFF8B5CF6)))
        ) else CardDefaults.outlinedCardBorder(),
        modifier = modifier.clickable { onBuy() }
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(10.dp)
        ) {
            Text(text = credits, color = Color(0xFFFBBF24), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = price, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtext, color = TextMutedDark, fontSize = 9.sp)
        }
    }
}

@Composable
fun LegendItem(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = label, color = TextSecondaryDark, fontSize = 10.sp)
    }
}
