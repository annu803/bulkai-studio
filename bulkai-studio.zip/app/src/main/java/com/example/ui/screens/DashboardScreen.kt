package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BulkAiRepository
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    repository: BulkAiRepository,
    onNavigate: (AppDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val credits by repository.credits.collectAsState()
    val jobs by repository.jobs.collectAsState()
    val projects by repository.projects.collectAsState()
    val isMockMode by repository.isMockMode.collectAsState()

    val activeJobsCount = jobs.count { it.status == JobStatus.PROCESSING || it.status == JobStatus.WAITING }
    val completedJobsCount = jobs.count { it.status == JobStatus.COMPLETED }
    val videoJobsCount = jobs.count { it.type == JobType.VIDEO && it.status == JobStatus.COMPLETED }
    val imageJobsCount = jobs.count { it.type == JobType.IMAGE && it.status == JobStatus.COMPLETED }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        // Hero SaaS Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.linearGradient(
                        listOf(Color(0xFF2563EB).copy(alpha = 0.5f), Color(0xFF7C3AED).copy(alpha = 0.5f))
                    )
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_hero_card")
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Surface(
                                color = Color(0xFF1E3A8A),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = if (isMockMode) "MOCK ENGINE READY" else "PRO PRODUCTION CLUSTER",
                                    color = Color(0xFF93C5FD),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Text(
                                text = "Pro Creator Tier",
                                color = TextSecondaryDark,
                                fontSize = 12.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "BulkAI Production Studio",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Generate massive parallel batches of AI videos, images, Hindi/English scripts and documentary scenes.",
                            color = TextSecondaryDark,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { onNavigate(AppDestination.BULK_VIDEO) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_quick_video")
                            ) {
                                Icon(Icons.Default.VideoCall, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Bulk Video", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            OutlinedButton(
                                onClick = { onNavigate(AppDestination.AI_SCRIPT) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_quick_script")
                            ) {
                                Icon(Icons.Default.AutoStories, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("AI Script", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Key Metrics 2x2 Grid
        item {
            Text(
                text = "STUDIO OVERVIEW",
                color = TextMutedDark,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Available Credits",
                    value = "$credits",
                    subtitle = "⚡ Ready to use",
                    icon = Icons.Default.Bolt,
                    accentColor = Color(0xFFFBBF24),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AppDestination.CREDITS) }
                )
                StatCard(
                    title = "Active Jobs",
                    value = "$activeJobsCount",
                    subtitle = "In queue / processing",
                    icon = Icons.Default.HourglassTop,
                    accentColor = Color(0xFF38BDF8),
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Videos Generated",
                    value = "$videoJobsCount",
                    subtitle = "4K / 1080p renders",
                    icon = Icons.Default.MovieCreation,
                    accentColor = Color(0xFFA855F7),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AppDestination.BULK_VIDEO) }
                )
                StatCard(
                    title = "Images Generated",
                    value = "$imageJobsCount",
                    subtitle = "High-res outputs",
                    icon = Icons.Default.Image,
                    accentColor = Color(0xFF10B981),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AppDestination.BULK_IMAGE) }
                )
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Recent Projects Section
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "RECENT PROJECTS",
                    color = TextMutedDark,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                TextButton(
                    onClick = { onNavigate(AppDestination.PROJECTS) },
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("View All (${projects.size})", color = Color(0xFF60A5FA), fontSize = 12.sp)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        items(projects.take(2)) { project ->
            Surface(
                color = SaaSSurfaceCard,
                shape = RoundedCornerShape(10.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(
                        listOf(SaaSSurfaceBorder, Color(0xFF3B82F6).copy(alpha = 0.2f))
                    )
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable { onNavigate(AppDestination.PROJECTS) }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E293B)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = null,
                            tint = Color(0xFF60A5FA),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = project.name,
                            color = TextPrimaryDark,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${project.type} • ${project.videoCount} videos • ${project.imageCount} images",
                            color = TextSecondaryDark,
                            fontSize = 11.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Open",
                        tint = TextMutedDark,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Live Queue Section
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "ACTIVE JOB QUEUE",
                    color = TextMutedDark,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                if (jobs.isNotEmpty()) {
                    Text(
                        text = "${jobs.size} Total Jobs",
                        color = Color(0xFF93C5FD),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))

            if (jobs.isEmpty()) {
                Surface(
                    color = SaaSSurfaceCard,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(Icons.Default.CloudQueue, contentDescription = null, tint = TextMutedDark, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No active jobs in queue", color = TextSecondaryDark, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Start bulk generation to queue up parallel jobs", color = TextMutedDark, fontSize = 11.sp)
                    }
                }
            }
        }

        items(jobs.take(4)) { job ->
            JobQueueItem(
                job = job,
                onRegenerate = { repository.regenerateJob(job.id) },
                onDelete = { repository.deleteJob(job.id) },
                onDownload = { /* Simulated download */ }
            )
        }
    }
}
