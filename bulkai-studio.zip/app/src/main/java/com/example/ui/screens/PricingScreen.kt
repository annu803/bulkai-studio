package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BulkAiRepository
import com.example.model.PricingPlan
import com.example.ui.theme.*

@Composable
fun PricingScreen(
    repository: BulkAiRepository,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isAnnual by remember { mutableStateOf(false) }

    val plans = listOf(
        PricingPlan(
            name = "FREE",
            priceMonthly = "₹0",
            priceAnnual = "₹0",
            creditsPerMonth = 50,
            features = listOf(
                "50 Free Trial Credits",
                "1 Video at a time (720p)",
                "Standard Queue Speed",
                "Watermarked Exports"
            )
        ),
        PricingPlan(
            name = "STARTER",
            priceMonthly = "₹99",
            priceAnnual = "₹79",
            creditsPerMonth = 250,
            features = listOf(
                "250 Monthly Credits",
                "2 Parallel Video Tasks",
                "1080p HD Video Output",
                "Hindi & English TTS Voices",
                "Commercial Usage License"
            )
        ),
        PricingPlan(
            name = "CREATOR",
            priceMonthly = "₹299",
            priceAnnual = "₹239",
            creditsPerMonth = 750,
            features = listOf(
                "750 Monthly Credits",
                "4 Concurrent Generations",
                "AI Documentary Maker (30 scenes)",
                "No Watermark on Exports",
                "Priority Rendering Queue"
            )
        ),
        PricingPlan(
            name = "PRO",
            priceMonthly = "₹599",
            priceAnnual = "₹479",
            creditsPerMonth = 1800,
            isPopular = true,
            features = listOf(
                "1,800 Monthly Credits",
                "8 Parallel Bulk Generations",
                "4K Ultra-HD 60FPS Video",
                "Google Veo 2 + Kling v1.5 Access",
                "CSV / TXT Bulk Prompt Importer",
                "Full Audio Stem Downloads"
            )
        ),
        PricingPlan(
            name = "STUDIO",
            priceMonthly = "₹999",
            priceAnnual = "₹799",
            creditsPerMonth = 4000,
            features = listOf(
                "4,000 Monthly Credits",
                "Unlimited Parallel Tasks",
                "Highest Priority GPU Cluster",
                "Custom AI Model Fine-tuning",
                "Dedicated Account Manager & API"
            )
        )
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp)
    ) {
        // Header
        item {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Commercial SaaS Plans",
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Scale your content agency or YouTube studio with bulk AI generation",
                    color = TextSecondaryDark,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Monthly / Annual toggle
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(SaaSSurfaceCard)
                        .padding(4.dp)
                ) {
                    Surface(
                        color = if (!isAnnual) Color(0xFF1E3A8A) else Color.Transparent,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.clickable { isAnnual = false }
                    ) {
                        Text(
                            text = "Monthly Billing",
                            color = if (!isAnnual) Color.White else TextSecondaryDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                    Surface(
                        color = if (isAnnual) Color(0xFF1E3A8A) else Color.Transparent,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.clickable { isAnnual = true }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                            Text(
                                text = "Annual Billing",
                                color = if (isAnnual) Color.White else TextSecondaryDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(
                                color = Color(0xFF064E3B),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "20% OFF",
                                    color = Color(0xFF6EE7B7),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Plan Cards
        items(plans) { plan ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = if (plan.isPopular) {
                        Brush.horizontalGradient(listOf(Color(0xFF3B82F6), Color(0xFF8B5CF6)))
                    } else {
                        Brush.horizontalGradient(listOf(SaaSSurfaceBorder, SaaSSurfaceBorder))
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("plan_card_${plan.name.lowercase()}")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = plan.name,
                                color = if (plan.isPopular) Color(0xFF60A5FA) else Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "${plan.creditsPerMonth} Monthly Credits",
                                color = Color(0xFFFBBF24),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (plan.isPopular) {
                            Surface(
                                color = Color(0xFF1E3A8A),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "MOST POPULAR",
                                    color = Color(0xFF93C5FD),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = if (isAnnual) plan.priceAnnual else plan.priceMonthly,
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (plan.priceMonthly == "₹0") " / forever" else " / month",
                            color = TextSecondaryDark,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = SaaSSurfaceBorder, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Feature checks
                    plan.features.forEach { feat ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (plan.isPopular) Color(0xFF60A5FA) else Color(0xFF10B981),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = feat, color = TextPrimaryDark, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (plan.name == "PRO") {
                                Toast.makeText(context, "You are already on the PRO plan!", Toast.LENGTH_SHORT).show()
                            } else {
                                repository.topUpCredits(plan.creditsPerMonth)
                                Toast.makeText(context, "Upgraded to ${plan.name}! Credited ${plan.creditsPerMonth} credits.", Toast.LENGTH_LONG).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (plan.isPopular) Color(0xFF2563EB) else Color(0xFF1E293B)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                    ) {
                        Text(
                            text = if (plan.isPopular) "ACTIVE / CURRENT PLAN" else "UPGRADE TO ${plan.name}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (plan.isPopular) Color.White else Color(0xFF93C5FD)
                        )
                    }
                }
            }
        }
    }
}
