package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BulkAiRepository
import com.example.model.*
import com.example.ui.components.AppDestination
import com.example.ui.components.SelectableChip
import com.example.ui.theme.*

@Composable
fun ScriptToSceneScreen(
    repository: BulkAiRepository,
    onNavigate: (AppDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentScript by repository.currentScript.collectAsState()
    val isGenerating by repository.isGeneratingScript.collectAsState()

    var topicInput by remember {
        mutableStateOf("भारत के सबसे ज्यादा आबादी वाले 10 शहर")
    }
    var selectedSceneCount by remember { mutableStateOf(12) }
    var selectedLanguage by remember { mutableStateOf("Hindi") }

    val sceneCounts = listOf(12, 20, 30, 50)
    val languages = listOf("Hindi", "English", "Hinglish")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp)
    ) {
        // Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "AI Documentary Maker",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Script-to-Scene engine with multi-lingual voiceover generation",
                        color = TextSecondaryDark,
                        fontSize = 12.sp
                    )
                }
                Surface(
                    color = Color(0xFF4C1D95),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "AI Script Engine",
                        color = Color(0xFFDDD6FE),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Input Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(
                        listOf(SaaSSurfaceBorder, Color(0xFF8B5CF6).copy(alpha = 0.3f))
                    )
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "DOCUMENTARY TOPIC",
                        color = TextMutedDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = topicInput,
                        onValueChange = { topicInput = it },
                        placeholder = { Text("e.g. 'भारत के सबसे ज्यादा आबादी वाले 10 शहर' or 'Secret Himalayan Glaciers'") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimaryDark,
                            unfocusedTextColor = TextPrimaryDark,
                            focusedBorderColor = Color(0xFF8B5CF6),
                            unfocusedBorderColor = SaaSSurfaceBorder,
                            focusedContainerColor = SaaSSurface,
                            unfocusedContainerColor = SaaSSurface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_documentary_topic")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Preset Topics
                    Text("Sample Presets:", color = TextMutedDark, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = SaaSSurfaceElevated,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    topicInput = "भारत के सबसे ज्यादा आबादी वाले 10 शहर"
                                    selectedLanguage = "Hindi"
                                }
                        ) {
                            Text(
                                text = "10 Populated Cities",
                                color = TextSecondaryDark,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                        Surface(
                            color = SaaSSurfaceElevated,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    topicInput = "Sacred Temples & Architecture of Ancient India"
                                    selectedLanguage = "English"
                                }
                        ) {
                            Text(
                                text = "Ancient Temples",
                                color = TextSecondaryDark,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Scene count selector
                    Text("Select Scene Count", color = TextSecondaryDark, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        sceneCounts.forEach { count ->
                            SelectableChip(
                                label = "$count scenes",
                                isSelected = selectedSceneCount == count,
                                onClick = { selectedSceneCount = count },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Language selector
                    Text("Voice-over Language", color = TextSecondaryDark, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        languages.forEach { lang ->
                            SelectableChip(
                                label = lang,
                                isSelected = selectedLanguage == lang,
                                onClick = { selectedLanguage = lang },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Action button
                    Button(
                        onClick = {
                            if (topicInput.isBlank()) {
                                Toast.makeText(context, "Enter a topic first", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            repository.generateDocumentaryScript(topicInput, selectedSceneCount, selectedLanguage)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("btn_generate_script")
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Formulating Documentary Script...", fontSize = 13.sp)
                        } else {
                            Icon(Icons.Default.AutoStories, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("GENERATE SCRIPT & SCENES", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Generated Script Output
        currentScript?.let { script ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                    shape = RoundedCornerShape(14.dp),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Surface(
                                color = Color(0xFF064E3B),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "${script.scenes.size} SCENES GENERATED",
                                    color = Color(0xFF6EE7B7),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "Language: ${script.language}",
                                color = TextSecondaryDark,
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = script.title,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = script.introduction,
                            color = TextSecondaryDark,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Workflow Export Controls: Export to Bulk Video / Export to Voice
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    repository.exportScenesToBulkVideo(script)
                                    Toast.makeText(context, "Exported ${script.scenes.size} scenes to Bulk Video Queue!", Toast.LENGTH_LONG).show()
                                    onNavigate(AppDestination.BULK_VIDEO)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_export_to_bulk_video")
                            ) {
                                Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Generate All Videos", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    val fullVoiceText = script.scenes.joinToString("\n\n") { it.voiceOverText }
                                    repository.addVoiceJob(
                                        text = fullVoiceText,
                                        config = VoiceConfig(language = script.language)
                                    )
                                    Toast.makeText(context, "Queued Documentary voiceover synthesis!", Toast.LENGTH_SHORT).show()
                                    onNavigate(AppDestination.VOICE_OVER)
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF8B5CF6)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_generate_voiceover")
                            ) {
                                Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Generate Voice-over", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Scene-by-scene Breakdown Cards
            items(script.scenes) { scene ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                    shape = RoundedCornerShape(10.dp),
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = scene.title,
                                color = Color(0xFF60A5FA),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                color = SaaSSurfaceElevated,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "${scene.durationSec}s • ${scene.shotType}",
                                    color = TextMutedDark,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Video prompt
                        Text(
                            text = "🎬 VIDEO PROMPT:",
                            color = Color(0xFF93C5FD),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = scene.videoPrompt,
                            color = TextPrimaryDark,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Voice over script
                        Text(
                            text = "🎙️ HINDI / ENGLISH VOICE-OVER:",
                            color = Color(0xFFC084FC),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = scene.voiceOverText,
                            color = TextSecondaryDark,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
