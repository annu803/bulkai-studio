package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BulkAiRepository
import com.example.model.ModelTier
import com.example.model.ProviderStatus
import com.example.ui.components.SelectableChip
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    repository: BulkAiRepository,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isMockMode by repository.isMockMode.collectAsState()
    val selectedTier by repository.selectedTier.collectAsState()

    var parallelJobsLimit by remember { mutableStateOf("4") }
    var autoDownloadZip by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp)
    ) {
        // Header
        item {
            Text(
                text = "Studio Settings",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Model router configuration, mock simulation and export settings",
                color = TextSecondaryDark,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Mock Mode Toggle Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(
                        listOf(SaaSSurfaceBorder, if (isMockMode) Color(0xFF10B981).copy(alpha = 0.4f) else Color(0xFF3B82F6).copy(alpha = 0.4f))
                    )
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_mock_mode_card")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.padding(16.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isMockMode) Icons.Default.CloudQueue else Icons.Default.CloudDone,
                                contentDescription = null,
                                tint = if (isMockMode) Color(0xFF34D399) else Color(0xFF60A5FA),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Mock Engine Mode",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isMockMode)
                                "Zero API charges. Simulates realistic rendering delays, progress increments and outputs without billing paid endpoints."
                            else
                                "Connected directly to live AI endpoints (Veo 2, Kling v1.5, Midjourney, ElevenLabs).",
                            color = TextSecondaryDark,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Switch(
                        checked = isMockMode,
                        onCheckedChange = {
                            repository.setMockMode(it)
                            val modeStr = if (it) "Mock Mode Enabled" else "Live API Mode Enabled"
                            Toast.makeText(context, modeStr, Toast.LENGTH_SHORT).show()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF059669)
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // AI Model Router Configuration
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "AI MODEL ROUTER TIER",
                        color = TextMutedDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Select default model cluster for batch jobs based on your speed vs quality preference:",
                        color = TextSecondaryDark,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ModelTier.values().forEach { tier ->
                            SelectableChip(
                                label = tier.displayName,
                                isSelected = selectedTier == tier,
                                onClick = { repository.setModelTier(tier) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        color = ObsidianBackground,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("Active Model Mapping:", color = TextSecondaryDark, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("• Video: ${repository.aiRouter.resolveVideoModel(selectedTier)}", color = Color(0xFF93C5FD), fontSize = 11.sp)
                            Text("• Image: ${repository.aiRouter.resolveImageModel(selectedTier)}", color = Color(0xFFA7F3D0), fontSize = 11.sp)
                            Text("• Voice: ${repository.aiRouter.resolveVoiceModel(selectedTier)}", color = Color(0xFFDDD6FE), fontSize = 11.sp)
                            Text("• Script: ${repository.aiRouter.resolveScriptModel(selectedTier)}", color = Color(0xFFFDE68A), fontSize = 11.sp)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Security & API Keys Info Box
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SECURITY & SECRETS ARCHITECTURE",
                            color = TextMutedDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "BulkAI Studio enforces backend credential isolation. API keys are never exposed in browser or client code. They are configured via .env / AI Studio Secrets panel into BuildConfig.",
                        color = TextSecondaryDark,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        color = ObsidianBackground,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("Current Provider Statuses:", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            val isMock = repository.aiRouter.isMockMode()
                            val imageMode = repository.aiRouter.getCurrentImageMode()
                            val repStatus = repository.aiRouter.getReplicateEconomyProvider().getStatus()
                            Text(
                                "• Image Engine: ${if (isMock) "Mock Mode (Simulated)" else "Replicate (${imageMode.displayName})"}",
                                color = if (isMock) Color(0xFF10B981) else Color(0xFF38BDF8),
                                fontSize = 11.sp
                            )
                            Text(
                                "• Replicate Token: ${if (repStatus == ProviderStatus.CONFIGURED) "Configured in Secrets" else "Missing / Not set"}",
                                color = if (repStatus == ProviderStatus.CONFIGURED) Color(0xFF10B981) else Color(0xFFF59E0B),
                                fontSize = 11.sp
                            )
                            Text("• Video Engine: Mock Mode (Simulated Temporal)", color = Color(0xFF10B981), fontSize = 11.sp)
                            Text("• Voice Synthesis: Mock Mode (Simulated TTS)", color = Color(0xFF10B981), fontSize = 11.sp)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Parallel Processing & Performance
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "CONCURRENCY & EXPORT DEFAULTS",
                        color = TextMutedDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text("Parallel Render Slots", color = TextPrimaryDark, fontSize = 13.sp)
                            Text("Number of jobs processing simultaneously", color = TextMutedDark, fontSize = 11.sp)
                        }
                        Surface(
                            color = Color(0xFF1E293B),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("3 - 4 Workers", color = Color(0xFF93C5FD), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text("Auto Package ZIP Archive", color = TextPrimaryDark, fontSize = 13.sp)
                            Text("Bundle all finished renders automatically", color = TextMutedDark, fontSize = 11.sp)
                        }
                        Switch(
                            checked = autoDownloadZip,
                            onCheckedChange = { autoDownloadZip = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF2563EB))
                        )
                    }
                }
            }
        }
    }
}
