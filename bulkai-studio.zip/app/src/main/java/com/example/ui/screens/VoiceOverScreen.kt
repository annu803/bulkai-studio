package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BulkAiRepository
import com.example.model.*
import com.example.ui.components.JobQueueItem
import com.example.ui.components.SelectableChip
import com.example.ui.theme.*

@Composable
fun VoiceOverScreen(
    repository: BulkAiRepository,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val jobs by repository.jobs.collectAsState()
    val voiceJobs = remember(jobs) { jobs.filter { it.type == JobType.VOICE } }
    val currentScript by repository.currentScript.collectAsState()

    var scriptText by remember {
        mutableStateOf(
            "भारत के सबसे बड़े शहरों की कहानी केवल इमारतों की नहीं, बल्कि यहाँ बसने वाले करोड़ों लोगों के सपनों और उनकी असीम ऊर्जा की है..."
        )
    }

    var selectedLanguage by remember { mutableStateOf("Hindi") }
    var selectedSpeaker by remember { mutableStateOf("Aarav") }
    var selectedGender by remember { mutableStateOf("Male") }
    var selectedStyle by remember { mutableStateOf("Documentary") }
    var speedVal by remember { mutableStateOf(1.0f) }
    var pitchVal by remember { mutableStateOf(1.0f) }
    var selectedEmotion by remember { mutableStateOf("Inspiring") }

    var isSimulatedPlaying by remember { mutableStateOf(false) }

    val languages = listOf("Hindi", "English", "Hinglish")
    val styles = listOf("Documentary", "Storytelling", "News", "Dramatic", "Calm")
    val emotions = listOf("Neutral", "Inspiring", "Intense", "Somber", "Warm")

    val speakers = listOf(
        VoiceProfile("v1", "Aarav", "Hindi", "Male", "Deep, resonant documentary narrator"),
        VoiceProfile("v2", "Ananya", "Hindi", "Female", "Warm, engaging storytelling voice"),
        VoiceProfile("v3", "Rohan", "English", "Male", "Authoritative international documentary tone"),
        VoiceProfile("v4", "Priya", "English", "Female", "Crisp, dynamic corporate narrator"),
        VoiceProfile("v5", "Kabir", "Hinglish", "Male", "Modern urban storyteller")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp)
    ) {
        // Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "Voice Over Studio",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Multi-lingual studio quality neural voiceover generation",
                        color = TextSecondaryDark,
                        fontSize = 12.sp
                    )
                }
                Surface(
                    color = Color(0xFF1E1B4B),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "Hindi & English TTS",
                        color = Color(0xFFC084FC),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Script input card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "VOICEOVER SCRIPT",
                            color = TextMutedDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        if (currentScript != null) {
                            TextButton(
                                onClick = {
                                    val full = currentScript?.scenes?.joinToString("\n\n") { it.voiceOverText }
                                    if (!full.isNullOrEmpty()) {
                                        scriptText = full
                                        Toast.makeText(context, "Loaded script from AI Documentary!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("Load AI Documentary Script", color = Color(0xFF60A5FA), fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = scriptText,
                        onValueChange = { scriptText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimaryDark,
                            unfocusedTextColor = TextPrimaryDark,
                            focusedBorderColor = Color(0xFF8B5CF6),
                            unfocusedBorderColor = SaaSSurfaceBorder,
                            focusedContainerColor = SaaSSurface,
                            unfocusedContainerColor = SaaSSurface
                        )
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Voice Character & Language Selection
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "VOICE ACTOR SELECTION",
                        color = TextMutedDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Language chips
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        languages.forEach { lang ->
                            SelectableChip(
                                label = lang,
                                isSelected = selectedLanguage == lang,
                                onClick = {
                                    selectedLanguage = lang
                                    val match = speakers.firstOrNull { it.language == lang }
                                    if (match != null) {
                                        selectedSpeaker = match.name
                                        selectedGender = match.gender
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Speaker cards
                    Text("Select Voice Talent", color = TextSecondaryDark, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        speakers.filter { it.language == selectedLanguage }.forEach { speaker ->
                            val isSelected = selectedSpeaker == speaker.name
                            Surface(
                                color = if (isSelected) Color(0xFF1E293B) else SaaSSurfaceElevated,
                                shape = RoundedCornerShape(8.dp),
                                border = if (isSelected) CardDefaults.outlinedCardBorder().copy(
                                    brush = Brush.horizontalGradient(listOf(Color(0xFF8B5CF6), Color(0xFF60A5FA)))
                                ) else null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedSpeaker = speaker.name
                                        selectedGender = speaker.gender
                                    }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(if (isSelected) Color(0xFF7C3AED) else Color(0xFF334155)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Mic, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${speaker.name} (${speaker.gender})",
                                            color = if (isSelected) Color.White else TextPrimaryDark,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(text = speaker.description, color = TextMutedDark, fontSize = 10.sp)
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Voice Modulation Controls (Speed, Pitch, Emotion, Style)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "VOICE MODULATION & TONE",
                        color = TextMutedDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Narrative Style", color = TextSecondaryDark, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(styles) { st ->
                            SelectableChip(
                                label = st,
                                isSelected = selectedStyle == st,
                                onClick = { selectedStyle = st }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Emotional Tone", color = TextSecondaryDark, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(emotions) { em ->
                            SelectableChip(
                                label = em,
                                isSelected = selectedEmotion == em,
                                onClick = { selectedEmotion = em }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Speed slider
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Playback Speed", color = TextSecondaryDark, fontSize = 11.sp)
                        Text("${String.format("%.1fx", speedVal)}", color = Color(0xFF60A5FA), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = speedVal,
                        onValueChange = { speedVal = it },
                        valueRange = 0.5f..2.0f,
                        steps = 5,
                        colors = SliderDefaults.colors(thumbColor = Color(0xFF3B82F6), activeTrackColor = Color(0xFF3B82F6))
                    )

                    // Pitch slider
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Voice Pitch", color = TextSecondaryDark, fontSize = 11.sp)
                        Text("${String.format("%.1fx", pitchVal)}", color = Color(0xFF8B5CF6), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = pitchVal,
                        onValueChange = { pitchVal = it },
                        valueRange = 0.5f..1.5f,
                        steps = 4,
                        colors = SliderDefaults.colors(thumbColor = Color(0xFF8B5CF6), activeTrackColor = Color(0xFF8B5CF6))
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // GENERATE BUTTON
        item {
            Button(
                onClick = {
                    if (scriptText.isBlank()) {
                        Toast.makeText(context, "Please enter voiceover text", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    repository.addVoiceJob(
                        text = scriptText,
                        config = VoiceConfig(
                            language = selectedLanguage,
                            voiceName = selectedSpeaker,
                            gender = selectedGender,
                            style = selectedStyle,
                            speed = speedVal,
                            pitch = pitchVal,
                            emotion = selectedEmotion
                        )
                    )
                    Toast.makeText(context, "Synthesizing voiceover with $selectedSpeaker...", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_generate_voice")
            ) {
                Icon(Icons.Default.SpatialAudioOff, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("SYNTHESIZE VOICEOVER", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Simulated Audio Player Preview
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SaaSSurfaceCard),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(SaaSSurfaceBorder, Color(0xFF8B5CF6).copy(alpha = 0.3f)))
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF2563EB).copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Headphones, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Live Audio Player Preview", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("$selectedSpeaker ($selectedLanguage) • $selectedStyle", color = TextSecondaryDark, fontSize = 10.sp)
                            }
                        }

                        IconButton(
                            onClick = {
                                Toast.makeText(context, "Exporting lossless audio (WAV / MP3)...", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.Download, contentDescription = "Download Audio", tint = Color(0xFF93C5FD))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Waveform visualizer bars
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(ObsidianBackground)
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val infiniteTransition = rememberInfiniteTransition(label = "waveform")
                        val barHeights = listOf(14, 28, 38, 22, 34, 18, 26, 40, 30, 16, 32, 24, 36, 20, 30, 26, 38, 18, 28, 32, 14, 30)

                        barHeights.forEachIndexed { idx, baseHeight ->
                            val dynamicHeight by infiniteTransition.animateFloat(
                                initialValue = if (isSimulatedPlaying) (baseHeight * 0.4f) else 10f,
                                targetValue = if (isSimulatedPlaying) (baseHeight * 1.0f) else 10f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(400 + (idx * 30), easing = FastOutSlowInEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "bar_$idx"
                            )

                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(dynamicHeight.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(
                                        if (isSimulatedPlaying) Color(0xFF38BDF8) else Color(0xFF475569)
                                    )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Player controls
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isSimulatedPlaying) "00:18" else "00:00", color = TextSecondaryDark, fontSize = 11.sp)

                        FilledIconButton(
                            onClick = { isSimulatedPlaying = !isSimulatedPlaying },
                            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF2563EB)),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Icon(
                                imageVector = if (isSimulatedPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isSimulatedPlaying) "Pause" else "Play",
                                tint = Color.White
                            )
                        }

                        Text("01:24", color = TextSecondaryDark, fontSize = 11.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // Voice Over queue items
        item {
            Text(
                text = "VOICE GENERATION HISTORY",
                color = TextMutedDark,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        if (voiceJobs.isEmpty()) {
            item {
                Surface(
                    color = SaaSSurfaceCard,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Icon(Icons.Default.MicNone, contentDescription = null, tint = TextMutedDark, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("No voice jobs synthesized yet", color = TextSecondaryDark, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(voiceJobs) { job ->
                JobQueueItem(
                    job = job,
                    onRegenerate = { repository.regenerateJob(job.id) },
                    onDelete = { repository.deleteJob(job.id) },
                    onDownload = {
                        Toast.makeText(context, "Downloading audio track for ${job.jobNumber}", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}
