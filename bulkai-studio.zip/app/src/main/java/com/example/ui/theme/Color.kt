package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Dark SaaS Theme Palette
val ObsidianBackground = Color(0xFF080C14)
val SaaSSurface = Color(0xFF0F172A)
val SaaSSurfaceCard = Color(0xFF162036)
val SaaSSurfaceElevated = Color(0xFF1E293B)
val SaaSSurfaceBorder = Color(0xFF28354D)

val CyberBluePrimary = Color(0xFF3B82F6)
val CyberBlueSecondary = Color(0xFF60A5FA)
val ElectricCyan = Color(0xFF06B6D4)
val VioletAccent = Color(0xFF8B5CF6)
val NeonEmerald = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RoseError = Color(0xFFF43F5E)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

// Legacy colors for backwards compatibility
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

