package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val SaaSColorScheme =
  darkColorScheme(
    primary = CyberBluePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = Color(0xFFDBEAFE),
    secondary = ElectricCyan,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF164E63),
    onSecondaryContainer = Color(0xFFCFFAFE),
    tertiary = VioletAccent,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF4C1D95),
    onTertiaryContainer = Color(0xFFEDE9FE),
    background = ObsidianBackground,
    onBackground = TextPrimaryDark,
    surface = SaaSSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = SaaSSurfaceCard,
    onSurfaceVariant = TextSecondaryDark,
    outline = SaaSSurfaceBorder,
    error = RoseError,
    onError = Color.White
  )

@Composable
fun BulkAITheme(
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = SaaSColorScheme,
    typography = Typography,
    content = content
  )
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  BulkAITheme(content = content)
}

