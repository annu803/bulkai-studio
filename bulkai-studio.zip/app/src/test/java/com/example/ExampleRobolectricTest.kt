package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("BulkAI Studio", appName)
  }

  @Test
  fun `test bulk prompt parsing`() {
    val repo = com.example.data.BulkAiRepository.getInstance()
    val rawText = """
      Prompt 1:
      A cinematic aerial view of Kedarnath temple.
      
      Prompt 2:
      A realistic documentary scene showing rainfall.
      
      Prompt 3:
      A massive river flood in Himalayas.
    """.trimIndent()

    val parsed = repo.parseBulkPrompts(rawText)
    assertEquals(3, parsed.size)
    assertEquals("A cinematic aerial view of Kedarnath temple.", parsed[0])
    assertEquals("A realistic documentary scene showing rainfall.", parsed[1])
    assertEquals("A massive river flood in Himalayas.", parsed[2])
  }

  @Test
  fun `test project creation and credit balance`() {
    val repo = com.example.data.BulkAiRepository.getInstance()
    val initialCredits = repo.credits.value
    repo.topUpCredits(500)
    assertEquals(initialCredits + 500, repo.credits.value)

    val proj = repo.createProject("Test Project", "AI Documentary")
    assertEquals("Test Project", proj.name)
    assertEquals("AI Documentary", proj.type)
  }

  @Test
  fun `test parse CSV and TXT prompts`() {
    val repo = com.example.data.BulkAiRepository.getInstance()
    val sampleCsv = repo.getSampleCsvContent()
    val parsedCsv = repo.parseCsvPrompts(sampleCsv)
    assertEquals(10, parsedCsv.size)
    assert(parsedCsv[0].contains("ancient Indian stone temple", ignoreCase = true))

    val sampleTxt = repo.getSampleTxtContent()
    val parsedTxt = repo.parseTxtPrompts(sampleTxt)
    assertEquals(10, parsedTxt.size)
  }

  @Test
  fun `test mock image generation service`() = kotlinx.coroutines.runBlocking {
    val service = com.example.data.MockImageGenerationService()
    val result = service.generateImage(
      prompt = "A majestic royal Bengal tiger in morning mist",
      settings = com.example.data.ImageGenerationSettings(aspectRatio = "16:9", quality = "High", style = "Cinematic")
    )
    assert(!result.imageUrl.isNullOrBlank())
    assertEquals("3840x2160 (4K)", result.resolution)
  }

  @Test
  fun `test bulk image jobs queuing and project association`() {
    val repo = com.example.data.BulkAiRepository.getInstance()
    val proj = repo.createProject("Himalayan Series", "Image Campaign")

    val prompts = listOf(
      "Ancient mountain monastery at dawn",
      "Serene frozen lake in Ladakh"
    )

    repo.addBulkImageJobs(
      prompts = prompts,
      aspectRatio = "16:9",
      quality = "High",
      style = "Cinematic",
      tier = com.example.model.ModelTier.STANDARD,
      projectId = proj.id,
      imagesPerPrompt = 2
    )

    val imageJobs = repo.jobs.value.filter { it.projectId == proj.id }
    assertEquals(4, imageJobs.size)
    assertEquals("16:9", imageJobs[0].aspectRatio)
    assertEquals("High", imageJobs[0].quality)
    assertEquals("Cinematic", imageJobs[0].style)
  }

  @Test
  fun `test image provider routing economy real routes to replicate minimax-01`() = kotlinx.coroutines.runBlocking {
    val router = com.example.data.AiRouter(mockModeEnabled = false)
    router.setImageGenerationMode(com.example.data.providers.ImageGenerationMode.REPLICATE_ECONOMY)

    assertEquals("Replicate", router.getImageProvider().providerName)
    assertEquals(com.example.data.providers.ImageGenerationMode.REPLICATE_ECONOMY, router.getCurrentImageMode())
    assertEquals(com.example.data.providers.AiProviderPricingConfig.REPLICATE_ECONOMY_MODEL, router.getCurrentImageMode().modelIdentifier)
    assertEquals("minimax/image-01", com.example.data.providers.AiProviderPricingConfig.REPLICATE_ECONOMY_MODEL)

    val response = router.routeImageGeneration(
      jobId = "test-job-economy",
      prompt = "Ancient sunset over hills",
      settings = com.example.data.ImageGenerationSettings(aspectRatio = "1:1", quality = "Standard", style = "Realistic"),
      targetMode = com.example.data.providers.ImageGenerationMode.REPLICATE_ECONOMY
    )
    assertEquals("Replicate", response.providerName)
    assertEquals("minimax/image-01", response.modelName)
  }

  @Test
  fun `test image provider routing premium real routes to replicate imagen-4`() = kotlinx.coroutines.runBlocking {
    val router = com.example.data.AiRouter(mockModeEnabled = false)
    router.setImageGenerationMode(com.example.data.providers.ImageGenerationMode.REPLICATE_PREMIUM)

    assertEquals("Replicate", router.getImageProvider().providerName)
    assertEquals(com.example.data.providers.ImageGenerationMode.REPLICATE_PREMIUM, router.getCurrentImageMode())
    assertEquals(com.example.data.providers.AiProviderPricingConfig.REPLICATE_PREMIUM_MODEL, router.getCurrentImageMode().modelIdentifier)
    assertEquals("google/imagen-4", com.example.data.providers.AiProviderPricingConfig.REPLICATE_PREMIUM_MODEL)

    val response = router.routeImageGeneration(
      jobId = "test-job-premium",
      prompt = "Cinematic 8k shot",
      settings = com.example.data.ImageGenerationSettings(aspectRatio = "16:9", quality = "High", style = "Cinematic"),
      targetMode = com.example.data.providers.ImageGenerationMode.REPLICATE_PREMIUM
    )
    assertEquals("Replicate", response.providerName)
    assertEquals("google/imagen-4", response.modelName)
  }

  @Test
  fun `test image provider routing mock routes to mock provider only`() = kotlinx.coroutines.runBlocking {
    val router = com.example.data.AiRouter(mockModeEnabled = true)
    router.setImageGenerationMode(com.example.data.providers.ImageGenerationMode.MOCK)

    assertEquals("Mock", router.getImageProvider().providerName)
    assertEquals(com.example.data.providers.ImageGenerationMode.MOCK, router.getCurrentImageMode())

    val response = router.routeImageGeneration(
      jobId = "test-job-mock",
      prompt = "A serene forest lake",
      settings = com.example.data.ImageGenerationSettings(aspectRatio = "1:1", quality = "Standard", style = "Cinematic"),
      targetMode = com.example.data.providers.ImageGenerationMode.MOCK
    )
    assertEquals("Mock", response.providerName)
    assert(response.success)
    assert(!response.data?.imageUrl.isNullOrBlank())
  }

  @Test
  fun `test real image provider failure does not silently fallback to mock`() = kotlinx.coroutines.runBlocking {
    val router = com.example.data.AiRouter(mockModeEnabled = false)
    router.setImageGenerationMode(com.example.data.providers.ImageGenerationMode.REPLICATE_ECONOMY)

    // With no valid token configured in test JVM environment, it should fail with informative error and NEVER return mock success
    val response = router.routeImageGeneration(
      jobId = "test-fail-replicate",
      prompt = "Realistic mountain view",
      settings = com.example.data.ImageGenerationSettings(aspectRatio = "16:9", quality = "High", style = "Realistic"),
      targetMode = com.example.data.providers.ImageGenerationMode.REPLICATE_ECONOMY
    )
    assertEquals("Replicate", response.providerName)
    // Must NOT silently succeed with mock image
    org.junit.Assert.assertFalse(response.success)
    org.junit.Assert.assertNull(response.data)
    org.junit.Assert.assertNotNull(response.error)
  }

  @Test
  fun `verify replicate token exists and is not asterisks`() {
    val token = com.example.data.providers.ReplicateImageProvider.resolveServerToken()
    // Safe verification: confirms token presence and that it is not masked asterisks, without revealing its value
    org.junit.Assert.assertNotNull(token)
    org.junit.Assert.assertTrue("Token must exist and not be blank", token.isNotBlank())
    org.junit.Assert.assertFalse("Token must not be masked with asterisks", token.contains("*"))
    org.junit.Assert.assertTrue("Token must follow Replicate format", token.startsWith("r8_"))
  }

  @Test
  fun `verify masked placeholder with asterisks is strictly rejected`() {
    val maskedDisplayVal = "r8_UpJ**********************************"
    org.junit.Assert.assertTrue(com.example.data.providers.ReplicateImageProvider.isTokenMaskedPlaceholder(maskedDisplayVal))
    org.junit.Assert.assertFalse(com.example.data.providers.ReplicateImageProvider.isValidReplicateToken(maskedDisplayVal))
  }
}
